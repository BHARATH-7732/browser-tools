async function launch(){
 const msg=document.getElementById("msg");
 try{
  const [tab]=await chrome.tabs.query({active:true,currentWindow:true});
  if(!tab?.id||!/^https?:/.test(tab.url||"")){msg.textContent="Open the Consulti results page in a normal browser tab first.";return;}
  await chrome.scripting.executeScript({target:{tabId:tab.id},files:["content.js"]});
  msg.textContent="Workflow launched. Use the control panel on the page.";
  window.close();
 }catch(e){msg.textContent="Could not launch. Refresh the page and try again.";}
}
document.getElementById("start").addEventListener("click",launch);
