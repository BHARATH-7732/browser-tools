(() => {
  if (window.consultiHelper?.stop) window.consultiHelper.stop();
  document.querySelector("#consulti-helper-window")?.remove();
  document.querySelector("#consulti-helper-style")?.remove();

  const CFG = { maxPages: 9, loadTimeout: 180000, pollMs: 2500, afterSelectMs: 1200, unlockTimeout: 60000, emailStableChecks: 3, emailStableMs: 1500 };
  let running = false, stopped = false, currentPage = 0, csvDownloaded = false;
  const collectedEmails = new Set();
  // Limit Unlock Selected clicks to 2 per local system-clock minute.
  let unlockMinuteKey = "", unlockClicksThisMinute = 0;

  const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
  const allButtons = () => [...document.querySelectorAll("button")];
  const visible = el => !!el && el.getClientRects().length > 0;
  const findButton = pattern => allButtons().find(b =>
    visible(b) && pattern.test(`${b.innerText || ""} ${b.getAttribute("aria-label") || ""}`)
  );
  const rows = () => [...document.querySelectorAll("tbody tr")].filter(visible);
  const active = () => running && !stopped;

  const panel = document.createElement("section");
  panel.id = "consulti-helper-window";
  panel.innerHTML = `
    <header id="ch-drag"><span class="ch-brand"><span class="ch-dot"></span> Consulti Helper</span><button id="ch-close" class="ch-icon" title="Close">×</button></header>
    <div class="ch-status-line"><span class="ch-pulse"></span><span id="ch-status">Ready</span></div>
    <div class="ch-progress"><div class="ch-progress-top"><span>Progress</span><strong id="ch-page">Page 0 / 9</strong></div><div class="ch-track"><div id="ch-bar"></div></div></div>
    <div class="ch-progress-top"><span>Unique emails collected</span><strong id="ch-email-count">0</strong></div>
    <div class="ch-actions"><button id="ch-start" class="ch-btn ch-primary">Start full workflow</button><button id="ch-stop" class="ch-btn ch-red">Stop & download CSV</button></div>
    <div class="ch-note">For each page: select leads → unlock → verify credit deduction → collect visible emails → wait for collection to stabilize → next page. Stops for manual website confirmations. Maximum 2 unlock clicks per minute. Only collect addresses you are authorized to process.</div>
  `;

  const style = document.createElement("style");
  style.id = "consulti-helper-style";
  style.textContent = `
    #consulti-helper-window{position:fixed;right:20px;top:100px;z-index:2147483647;width:285px;box-sizing:border-box;padding:14px;color:#172033;background:#fff;border:1px solid #dbe3f2;border-radius:16px;box-shadow:0 12px 38px #18284a30;font:13px/1.4 Arial,sans-serif}
    #consulti-helper-window *{box-sizing:border-box}#consulti-helper-window #ch-drag{display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:14px;cursor:move;font-size:15px;font-weight:800}
    #consulti-helper-window .ch-brand{display:flex;align-items:center;gap:8px}#consulti-helper-window .ch-dot{width:10px;height:10px;border-radius:50%;background:linear-gradient(135deg,#2563eb,#9333ea);box-shadow:0 0 0 4px #ede9fe}
    #consulti-helper-window button{font:inherit}#consulti-helper-window .ch-icon{border:0;background:#f1f5f9;color:#475569;border-radius:8px;width:26px;height:26px;cursor:pointer;font-size:19px}
    #consulti-helper-window .ch-status-line{display:flex;align-items:center;gap:8px;padding:9px 10px;border-radius:9px;background:#f8fafc;color:#334155;min-height:36px}
    #consulti-helper-window .ch-pulse{width:8px;height:8px;flex:none;border-radius:50%;background:#2563eb}
    #consulti-helper-window .ch-progress{margin:14px 0}#consulti-helper-window .ch-progress-top{display:flex;justify-content:space-between;margin-bottom:7px;color:#64748b;font-size:12px}
    #consulti-helper-window #ch-page{color:#1e293b}#consulti-helper-window .ch-track{height:7px;overflow:hidden;background:#e8edf5;border-radius:20px}
    #consulti-helper-window #ch-bar{width:0%;height:100%;border-radius:20px;background:linear-gradient(90deg,#2563eb,#9333ea);transition:width .25s}
    #consulti-helper-window .ch-actions{display:grid;gap:8px}#consulti-helper-window .ch-btn{width:100%;padding:11px;border:0;border-radius:9px;color:#fff;font-weight:700;cursor:pointer}
    #consulti-helper-window .ch-btn:hover:not(:disabled){filter:brightness(1.08)}#consulti-helper-window .ch-btn:disabled{opacity:.5;cursor:not-allowed}
    #consulti-helper-window .ch-primary{background:linear-gradient(135deg,#2563eb,#7c3aed)}#consulti-helper-window .ch-red{background:linear-gradient(135deg,#e11d48,#f97316)}
    #consulti-helper-window .ch-note{margin-top:12px;padding-top:10px;border-top:1px solid #edf0f6;color:#64748b;font-size:11px;line-height:1.5}
  `;
  document.documentElement.appendChild(style);
  document.body.appendChild(panel);

  const status = (message, color = "#2563eb") => {
    const el = panel.querySelector("#ch-status"), dot = panel.querySelector(".ch-pulse");
    if (el) el.textContent = message;
    if (dot) dot.style.background = color;
    console.log("[Consulti Helper]", message);
  };
  const progress = () => {
    panel.querySelector("#ch-page").textContent = `Page ${currentPage} / ${CFG.maxPages}`;
    panel.querySelector("#ch-bar").style.width = `${currentPage / CFG.maxPages * 100}%`;
  };
  const stop = (message = "Stopped.") => {
    stopped = true; status(message, "#e11d48");
    panel.querySelector("#ch-start").disabled = false;
  };

  function creditBalance() {
    const text = document.body.innerText || "";
    // Supports common label variations, including the "800 FREE" style shown in the screenshot.
    const patterns = [
      /You have\s+([\d,]+)\s+lead credits/i,
      /([\d,]+)\s*(?:lead\s*)?credits?\s*(?:available)?/i,
      /([\d,]+)\s+FREE\b/i
    ];
    for (const pattern of patterns) {
      const m = text.match(pattern);
      if (m) return Number(m[1].replace(/,/g, ""));
    }
    return null;
  }
  function unlockCost(button) {
    const m = (button?.innerText || "").match(/([\d,]+)\s+credits?/i);
    return m ? Number(m[1].replace(/,/g, "")) : null;
  }
  function selectedOK() {
    return /All\s+100\s+leads\s+on\s+this\s+page\s+are\s+selected/i.test(document.body.innerText || "") ||
      /100\s+selected/i.test(document.body.innerText || "");
  }
  async function waitForPage() {
    const deadline = Date.now() + CFG.loadTimeout;
    let prev = -1, stable = 0;
    while (active() && Date.now() < deadline) {
      const text = document.body.innerText || "";
      const count = rows().length;
      if (!/Searching\.\.\.|Counting\.\.\./i.test(text) && count >= 1) {
        stable = count === prev ? stable + 1 : 0;
        prev = count;
        if (stable >= 2) return true;
      } else { prev = count; stable = 0; }
      status(`Waiting for page data… (${count} rows)`, "#d97706");
      await sleep(CFG.pollMs);
    }
    return false;
  }
  function updateEmailCount() {
    const el = panel.querySelector("#ch-email-count");
    if (el) el.textContent = String(collectedEmails.size);
  }
  function scanVisibleEmails() {
    const text = document.body.innerText || "";
    const found = text.match(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi) || [];
    for (const email of found) collectedEmails.add(email.toLowerCase());
    updateEmailCount();
    return found.length;
  }
  async function waitForEmailCollection() {
    const deadline = Date.now() + CFG.loadTimeout;
    let previous = "", stable = 0;
    while (active() && Date.now() < deadline) {
      const text = document.body.innerText || "";
      const loading = /searching\.\.\.|loading\.\.\.|counting\.\.\./i.test(text);
      const signature = `${rows().length}|${text.slice(-5000)}`;
      if (!loading && signature === previous) stable++;
      else stable = 0;
      previous = signature;
      if (stable >= CFG.emailStableChecks) {
        const count = scanVisibleEmails();
        status(`Email collection complete: ${count} matches (${collectedEmails.size} unique).`, "#059669");
        return true;
      }
      status("Waiting for unlocked email data to stabilize…", "#d97706");
      await sleep(CFG.emailStableMs);
    }
    return false;
  }
  function downloadCsv() {
    if (csvDownloaded) return;
    csvDownloaded = true;
    if (!collectedEmails.size) {
      status("Workflow ended; no visible email addresses were found.", "#d97706");
      return;
    }
    const quote = value => `"${String(value).replace(/"/g, '""')}"`;
    const csv = ["Email", ...[...collectedEmails].sort().map(quote)].join("\r\n");
    const url = URL.createObjectURL(new Blob(["\uFEFF", csv], { type: "text/csv;charset=utf-8" }));
    const link = document.createElement("a");
    link.href = url;
    link.download = `consulti_emails_${new Date().toISOString().slice(0, 10)}.csv`;
    document.body.appendChild(link); link.click(); link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 3000);
    status(`CSV ready: ${collectedEmails.size} unique emails.`, "#059669");
  }

  function localMinuteKey(date = new Date()) {
    // Date uses the computer/browser local system time, including its timezone.
    return `${date.getFullYear()}-${date.getMonth()}-${date.getDate()}-${date.getHours()}-${date.getMinutes()}`;
  }
  async function waitForUnlockSlot() {
    while (active()) {
      const now = new Date();
      const minuteKey = localMinuteKey(now);
      if (minuteKey !== unlockMinuteKey) {
        unlockMinuteKey = minuteKey;
        unlockClicksThisMinute = 0;
      }
      if (unlockClicksThisMinute < 2) {
        unlockClicksThisMinute++;
        return true;
      }
      const msUntilNextMinute = 60000 - (now.getSeconds() * 1000 + now.getMilliseconds());
      status(`Rate limit reached (2 unlocks/min). Waiting for ${new Date(now.getTime() + msUntilNextMinute).toLocaleTimeString()}…`, "#d97706");
      await sleep(Math.max(50, msUntilNextMinute));
    }
    return false;
  }

  async function waitForBalanceChange(before, cost) {
    const deadline = Date.now() + CFG.unlockTimeout;
    while (active() && Date.now() < deadline) {
      await sleep(1500);
      const now = creditBalance();
      if (before !== null && now !== null && now === before - cost) return true;
      // If the site uses a confirmation dialog, do not click through it.
      const dialog = [...document.querySelectorAll('[role="dialog"], [role="alertdialog"]')].find(visible);
      if (dialog) {
        status("Confirm the unlock on the website; then wait for verification.", "#d97706");
      }
    }
    return false;
  }

  async function run() {
    if (running) return;
    running = true; stopped = false; currentPage = 1; progress();
    panel.querySelector("#ch-start").disabled = true;
    try {
      for (let page = 1; page <= CFG.maxPages && active(); page++) {
        currentPage = page; progress();
        status(`Loading page ${page} of ${CFG.maxPages}…`, "#d97706");
        if (!(await waitForPage())) { if (active()) status("Page load timed out. Stopped safely.", "#e11d48"); break; }
        if (!active()) break;

        const selectAll = [...document.querySelectorAll('[role="checkbox"][aria-label], button[aria-label]')]
          .find(el => visible(el) && /select all rows on this page/i.test(el.getAttribute("aria-label") || ""));
        if (!selectAll) { status("Select-all control not found.", "#e11d48"); break; }
        if (selectAll.getAttribute("aria-checked") !== "true") {
          selectAll.click(); await sleep(CFG.afterSelectMs);
        }
        if (!selectedOK()) { status("Could not verify 100 selected. Stopped.", "#e11d48"); break; }

        const unlock = findButton(/unlock selected/i);
        const cost = unlockCost(unlock);
        const balance = creditBalance();
        if (!unlock || unlock.disabled || cost === null || cost <= 0) { status("Unlock button or cost not detected.", "#e11d48"); break; }
        if (balance === null) { status("Credit balance not detected; refusing to click to avoid an unintended charge.", "#e11d48"); break; }
        if (balance < cost) { status(`Insufficient credits: ${balance} available, ${cost} needed.`, "#e11d48"); break; }

        if (!(await waitForUnlockSlot())) break;
        // Re-check the live button and balance after any rate-limit wait.
        const readyUnlock = findButton(/unlock selected/i);
        const readyCost = unlockCost(readyUnlock);
        const readyBalance = creditBalance();
        if (!readyUnlock || readyUnlock.disabled || readyCost === null || readyCost <= 0 ||
            readyBalance === null || readyBalance < readyCost) {
          status("Unlock details changed while waiting; stopped safely without clicking.", "#e11d48");
          break;
        }
        status(`Page ${page}: clicking Unlock selected (${readyCost} credits). ${unlockClicksThisMinute}/2 clicks used this minute.`, "#d97706");
        readyUnlock.click();

        if (!(await waitForBalanceChange(readyBalance, readyCost))) {
          status("Could not verify credit deduction. Stopped; handle any website confirmation manually.", "#e11d48");
          break;
        }
        status(`Page ${page} unlock verified.`, "#059669");
        if (!(await waitForEmailCollection())) {
          if (active()) status("Email collection did not stabilize before timeout. Stopped safely.", "#e11d48");
          break;
        }
        if (!active()) break;
        if (page === CFG.maxPages) { status("Finished pages 1–9; preparing CSV.", "#059669"); break; }

        await sleep(1200);
        const next = findButton(/next page/i);
        if (!next || next.disabled) { status("Next page button unavailable.", "#e11d48"); break; }
        next.click();
        status(`Moving to page ${page + 1}…`, "#d97706");
        if (!(await waitForPage())) { status("Next page timed out. Stopped safely.", "#e11d48"); break; }
      }
    } catch (e) {
      console.error(e);
      status("Error encountered. Stopped safely.", "#e11d48");
    } finally {
      running = false;
      panel.querySelector("#ch-start").disabled = false;
      downloadCsv();
    }
  }

  panel.querySelector("#ch-start").addEventListener("click", run);
  panel.querySelector("#ch-stop").addEventListener("click", () => {
    stop("Stopped by user.");
    if (!running) downloadCsv();
  });
  panel.querySelector("#ch-close").addEventListener("click", () => {
    stop("Panel closed."); panel.remove(); style.remove();
  });
  const head = panel.querySelector("#ch-drag");
  let dragging = false, sx = 0, sy = 0, ox = 0, oy = 0;
  head.addEventListener("mousedown", e => {
    if (e.target.closest("button")) return;
    dragging = true; const r = panel.getBoundingClientRect();
    sx = e.clientX; sy = e.clientY; ox = r.left; oy = r.top; e.preventDefault();
  });
  document.addEventListener("mousemove", e => {
    if (!dragging || !panel.isConnected) return;
    panel.style.left = `${ox + e.clientX - sx}px`; panel.style.top = `${oy + e.clientY - sy}px`; panel.style.right = "auto";
  });
  document.addEventListener("mouseup", () => dragging = false);
  window.consultiHelper = { start: run, stop: () => stop("Stopped.") };
  status("Ready. Ready. Start the full unlock → email collection workflow.", "#2563eb");
})();