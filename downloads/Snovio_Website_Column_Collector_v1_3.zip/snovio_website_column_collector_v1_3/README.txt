SNOV.IO WEBSITE COLUMN COLLECTOR v1.3

This version targets the Website column specifically, instead of collecting any link on the page.

INSTALL
1. Extract this ZIP.
2. Open chrome://extensions.
3. Enable Developer mode.
4. Click Load unpacked and select the extracted folder.
5. Refresh your Snov.io Companies page.

USE
1. Open Snov.io Companies and set the desired rows per page.
2. Open the extension and enter the number of pages.
3. Press Start.
4. It reads the Website column values on each page, waits 5–8 seconds, clicks Next, waits for the page to change, and repeats.
5. It downloads Snovio_Website_Column.csv when the requested number of pages or the last page is reached.

CONTROLS
Start = new run, clears previous collection.
Stop = pause without clearing.
Resume = continue from current page.
Reset = clear collected values and progress.
Download CSV = download values collected so far.

The collector reads the cell under the Website header and accepts linked website URLs and plain-text domains/URLs. It deduplicates exact normalized URLs. Verify a small test run first because Snov.io may change its table markup or virtualize rows. Keep the tab open and use only data you are authorized to export.
