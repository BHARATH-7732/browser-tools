(() => {
if(window.__snovCollectorV13)return;window.__snovCollectorV13=true;
const KEY="collectorState",sleep=ms=>new Promise(r=>setTimeout(r,ms));
async function get(){const d=await chrome.storage.local.get(KEY);return d[KEY]||{status:"ready",pageLimit:11,urls:[],pagesScanned:0,page:"1",message:"Ready."};}
async function put(p){const n={...(await get()),...p,updatedAt:Date.now()};await chrome.storage.local.set({[KEY]:n});return n;}
function page(){return new URL(location.href).searchParams.get("page")||"1";}
function norm(value){
 let raw=(value||"").trim();if(!raw)return null;
 if(/^mailto:|^javascript:/i.test(raw))return null;
 if(/^www\./i.test(raw))raw="https://"+raw;
 if(!/^https?:\/\//i.test(raw)){
   if(!/^[a-z0-9-]+(?:\.[a-z0-9-]+)+(?::\d+)?(?:[/?#]\S*)?$/i.test(raw))return null;
   raw="https://"+raw;
 }
 try{
   const u=new URL(raw),h=u.hostname.toLowerCase();
   if(!["http:","https:"].includes(u.protocol))return null;
   if(h==="app.snov.io"||h.endsWith(".snov.io")||/linkedin|facebook|instagram|youtube|twitter|x\.com|google/i.test(h))return null;
   return u.href;
 }catch{return null;}
}
function visible(el){return !!(el&&el.getClientRects().length);}
function textValue(cell){
 const a=cell.querySelector("a[href]");
 if(a){const href=norm(a.getAttribute("href")||a.href);if(href)return href;}
 const candidates=[cell.innerText||cell.textContent||"",cell.getAttribute("title")||"",cell.getAttribute("data-value")||""];
 for(const v of candidates){const n=norm(v);if(n)return n;}
 return null;
}
function headerCells(row){
 return [...row.querySelectorAll('th,[role="columnheader"],td,[role="cell"]')].filter(visible);
}
function findWebsiteColumn(){
 const all=[...document.querySelectorAll('th,[role="columnheader"],[role="row"]')].filter(visible);
 for(const el of all){
   const txt=(el.innerText||el.textContent||"").trim().replace(/\s+/g," ").toLowerCase();
   if(txt==="website"||txt==="websites"){
     const row=el.matches('[role="row"]')?el:el.closest('tr,[role="row"]');
     if(row){
       const cells=headerCells(row),idx=cells.findIndex(c=>c===el||c.contains(el));
       if(idx>=0)return {row,index:idx};
     }
   }
 }
 // Fallback for Snov.io's div-based table: find a visible Website heading and use its position among sibling header cells.
 const headings=[...document.querySelectorAll("div,span")].filter(visible).filter(el=>{
   if(el.children.length>2)return false;
   return (el.innerText||el.textContent||"").trim().toLowerCase()==="website";
 }).sort((a,b)=>a.getBoundingClientRect().width*a.getBoundingClientRect().height-b.getBoundingClientRect().width*b.getBoundingClientRect().height);
 for(const h of headings){
   let row=h.closest('[role="row"],tr');
   if(!row){
     let p=h.parentElement;
     while(p&&p!==document.body){
       const kids=[...p.children].filter(visible);
       if(kids.length>=2&&kids.some(x=>/company/i.test(x.innerText||""))){row=p;break;}
       p=p.parentElement;
     }
   }
   if(row){
     const cells=headerCells(row);
     const idx=cells.findIndex(c=>c===h||c.contains(h));
     if(idx>=0)return {row,index:idx};
   }
 }
 return null;
}
function rowsFromHeader(headerRow){
 const parent=headerRow.parentElement;if(!parent)return [];
 return [...parent.children].filter(el=>el!==headerRow&&visible(el));
}
function scanWebsiteColumn(){
 const values=[],seen=new Set();
 const header=findWebsiteColumn();
 if(header){
   const rows=rowsFromHeader(header.row);
   for(const row of rows){
     let cells=[...row.querySelectorAll('td,[role="cell"]')].filter(visible);
     if(!cells.length)cells=[...row.children].filter(visible);
     const cell=cells[header.index];
     if(!cell)continue;
     const value=textValue(cell);
     if(value&&!seen.has(value)){seen.add(value);values.push(value);}
   }
 }
 // Also inspect table rows where an explicit Website header can be mapped to the cell index.
 for(const table of document.querySelectorAll("table")){
   const trs=[...table.querySelectorAll("tr")],hr=trs.find(tr=>[...tr.querySelectorAll("th")].some(th=>/^\s*website\s*$/i.test(th.innerText||th.textContent||"")));
   if(!hr)continue;
   const hs=[...hr.querySelectorAll("th")],idx=hs.findIndex(th=>/^\s*website\s*$/i.test(th.innerText||th.textContent||""));
   for(const tr of trs){if(tr===hr)continue;const cells=[...tr.querySelectorAll("td")],v=cells[idx]&&textValue(cells[idx]);if(v&&!seen.has(v)){seen.add(v);values.push(v);}}
 }
 return values;
}
function nextButton(){const bs=[...document.querySelectorAll("button.pagination__arrow")];return bs.length?bs[bs.length-1]:null;}
function disabled(b){return !b||b.disabled||b.hasAttribute("disabled")||b.getAttribute("aria-disabled")==="true"||b.classList.contains("disabled");}
function signature(){return scanWebsiteColumn().slice(0,8).join("|");}
async function wait(ms){const end=Date.now()+ms;while(Date.now()<end){const s=await get();if(s.status==="paused")return"paused";if(s.status!=="running")return"stopped";await sleep(Math.min(250,end-Date.now()));}return"ok";}
async function changed(oldPage,oldSig){const end=Date.now()+25000;while(Date.now()<end){const s=await get();if(s.status==="paused")return"paused";if(s.status!=="running")return"stopped";if(page()!==oldPage||(signature()&&signature()!==oldSig))return"changed";await sleep(350);}return"timeout";}
function download(urls){const csv=["Website",...urls.map(x=>`"${String(x).replace(/"/g,'""')}"`)].join("\r\n"),blob=new Blob(["\uFEFF"+csv],{type:"text/csv;charset=utf-8"}),u=URL.createObjectURL(blob),a=document.createElement("a");a.href=u;a.download="Snovio_Website_Column.csv";document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(u),10000);}
let active=false;
async function loop(){
 if(active)return;active=true;
 try{
  while(true){
   let s=await get();if(s.status==="paused"){await sleep(350);continue;}if(s.status!=="running")break;
   const urls=new Set(s.urls||[]),p=page(),found=scanWebsiteColumn(),added=[];
   for(const u of found)if(!urls.has(u)){urls.add(u);added.push(u);}
   const scanned=Number(s.pagesScanned||0)+1;
   s=await put({urls:[...urls],pagesScanned:scanned,page:p,status:"running",message:`Page ${p}: read ${found.length} Website-column values (${added.length} new). Total: ${urls.size}.`});
   if(scanned>=Number(s.pageLimit||11)){await put({status:"complete",message:`Finished ${scanned} pages. Downloading ${urls.size} Website-column values.`});download([...urls]);break;}
   const b=nextButton();if(disabled(b)){await put({status:"complete",message:`Last page reached. Downloading ${urls.size} Website-column values.`});download([...urls]);break;}
   const delay=5000+Math.floor(Math.random()*3001);await put({message:`Page ${p} scanned. Waiting ${(delay/1000).toFixed(1)} seconds before Next.`});
   if(await wait(delay)!=="ok")continue;
   const btn=nextButton();if(disabled(btn))continue;
   const oldPage=page(),oldSig=signature();btn.click();
   if(await changed(oldPage,oldSig)==="timeout")await put({status:"paused",message:"Could not confirm page change. Check Snov.io and press Resume."});
  }
 }catch(e){await put({status:"error",message:"Error: "+(e?.message||String(e))});}
 finally{active=false;}
}
chrome.runtime.onMessage.addListener((m,s,r)=>{(async()=>{
 if(m.command==="START"){await put({status:"running",pageLimit:m.pageLimit,urls:[],pagesScanned:0,page:page(),message:"Started a new Website-column collection."});loop();r({ok:true});}
 else if(m.command==="PAUSE"){await put({status:"paused",message:"Paused. Press Resume to continue."});r({ok:true});}
 else if(m.command==="RESUME"){await put({status:"running",message:"Resuming Website-column scan; current page will be scanned before moving on."});loop();r({ok:true});}
 else if(m.command==="RESET"){await put({status:"ready",urls:[],pagesScanned:0,page:page(),message:"Reset complete. Website values and progress cleared."});r({ok:true});}
})();return true;});
get().then(s=>{if(s.status==="running")loop();});
})();