const params = new URLSearchParams(location.search);
const tabId = Number(params.get("tabId"));

const $ = id => document.getElementById(id);
const startBtn = $("start");
const pauseBtn = $("pause");
const stopBtn = $("stop");

$("target").textContent = tabId ? `Target Apollo tab ID: ${tabId}` : "No target tab found";

function render(message = {}) {
  if (message.status) $("status").textContent = message.status;
  if (message.state) $("state").textContent = message.state;
  if (message.cycle !== undefined) $("cycle").textContent = message.cycle;
  if (message.page !== undefined) $("page").textContent = message.page;

  const dot = $("dot");
  dot.className = "dot";
  if (message.kind === "running") dot.classList.add("running");
  if (message.kind === "waiting") dot.classList.add("waiting");
  if (message.kind === "error") dot.classList.add("error");

  const running = message.active !== false;
  startBtn.disabled = running;
  pauseBtn.disabled = !running;
  stopBtn.disabled = !running;
  pauseBtn.textContent = message.paused ? "Resume" : "Pause";
}

async function sendToTab(action) {
  if (!tabId) {
    render({state:"No target", status:"Reopen this panel from the Apollo tab.", kind:"error", active:false});
    return;
  }
  try {
    if (action === "start") {
      await chrome.scripting.executeScript({
        target: {tabId},
        files: ["content.js"]
      });
    }
    const response = await chrome.tabs.sendMessage(tabId, {type: action});
    if (response) render(response);
  } catch (e) {
    render({
      state: "Connection issue",
      status: "Could not reach the Apollo page. Refresh the Apollo tab, reopen this panel, and try again.",
      kind: "error",
      active: false
    });
  }
}

startBtn.addEventListener("click", () => sendToTab("start"));
pauseBtn.addEventListener("click", async () => {
  try {
    const response = await chrome.tabs.sendMessage(tabId, {type:"togglePause"});
    if (response) render(response);
  } catch {}
});
stopBtn.addEventListener("click", async () => {
  try {
    const response = await chrome.tabs.sendMessage(tabId, {type:"stop"});
    if (response) render(response);
  } catch {}
});

chrome.runtime.onMessage.addListener(message => {
  if (message && message.type === "automationStatus" && message.tabId === tabId) {
    render(message.payload);
  }
});

render({
  state:"Ready",
  status:"Open Apollo results, select Net New, then press Start.",
  kind:"idle",
  active:false
});