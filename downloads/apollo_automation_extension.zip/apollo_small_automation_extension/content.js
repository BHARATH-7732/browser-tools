(() => {
  if (window.__apolloSmallAutomationInstalled) return;
  window.__apolloSmallAutomationInstalled = true;

  const TOTAL_PAGES = 5;
  const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));

  let active = false;
  let paused = false;
  let stopped = false;
  let cycle = 0;
  let currentPage = "—";
  let pauseWaiters = [];

  const isVisible = el =>
    !!el &&
    el.getClientRects().length > 0 &&
    getComputedStyle(el).visibility !== "hidden" &&
    getComputedStyle(el).display !== "none";

  const isEnabled = el => !!el && !el.disabled;

  const findVisibleButton = text =>
    [...document.querySelectorAll("button")].find(el =>
      el.textContent.trim() === text && isVisible(el) && isEnabled(el)
    );

  const findSaveButton = () => {
    const original = document.querySelector(
      'button[data-cy="toolbar-action-save-people-button"]'
    );
    if (original && isVisible(original) && isEnabled(original)) return original;
    return findVisibleButton("Save");
  };

  const findSaveAccountsButton = () =>
    [...document.querySelectorAll('button[data-cy="confirm"], button[type="submit"], button')]
      .find(el =>
        el.textContent.trim().includes("Save Accounts") &&
        isVisible(el) && isEnabled(el)
      );

  const findNextButton = () => {
    const ariaButton = document.querySelector('button[aria-label="Next"]');
    if (ariaButton && isVisible(ariaButton) && isEnabled(ariaButton)) return ariaButton;
    return [...document.querySelectorAll("button")].find(button =>
      button.querySelector("i.apollo-icon-chevron-arrow-right") &&
      isVisible(button) && isEnabled(button)
    );
  };

  const findCheckbox = () => {
    const input = document.querySelector(
      'input[aria-label="View more options to select rows"]'
    );
    if (input && isVisible(input)) return input;
    return null;
  };

  const findTotalTab = () => {
    const selector =
      '#main-container-column-2 > div.zp_gvqlM > div > div > div > div.zp_dd7PY.companies-finder-shell-container > div.zp_Npm3e > div.zp_C8VPK > div > div > div.zp_slPGj > div > div > div > div:nth-child(1) > label > span > div';
    const original = document.querySelector(selector);
    if (original && isVisible(original)) return original;
    return [...document.querySelectorAll("label, [role='tab'], button")]
      .find(el => el.textContent.trim().startsWith("Total") && isVisible(el));
  };

  const findNetNewTab = () =>
    [...document.querySelectorAll("label, [role='tab'], button")]
      .find(el => el.textContent.trim().startsWith("Net New") && isVisible(el));

  function report(status, state = "Running", kind = "running") {
    const payload = {
      status, state, kind, active, paused, cycle, page: currentPage
    };
    chrome.runtime.sendMessage({
      type: "automationStatus",
      payload
    }).catch(() => {});
    window.postMessage({source:"apollo-small-automation", payload}, "*");
  }

  // Runtime messages from the extension panel.
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === "start") {
      if (!active) {
        active = true;
        paused = false;
        stopped = false;
        report("Starting automation…", "Running", "running");
        runLoop().catch(err => {
          report(`Stopped due to error: ${err.message}`, "Error", "error");
          active = false;
        });
      }
      sendResponse(snapshot());
      return true;
    }

    if (message.type === "togglePause") {
      if (active) {
        paused = !paused;
        if (!paused) {
          pauseWaiters.splice(0).forEach(resolve => resolve());
          report("Resumed.", "Running", "running");
        } else {
          report("Paused. Press Resume to continue.", "Paused", "waiting");
        }
      }
      sendResponse(snapshot());
      return true;
    }

    if (message.type === "stop") {
      stopped = true;
      active = false;
      paused = false;
      pauseWaiters.splice(0).forEach(resolve => resolve());
      report("Stopped by user.", "Stopped", "idle");
      sendResponse(snapshot());
      return true;
    }
  });

  function snapshot() {
    return {
      state: stopped ? "Stopped" : paused ? "Paused" : active ? "Running" : "Ready",
      status: stopped ? "Stopped by user." : paused ? "Paused." : active ? "Automation running." : "Ready.",
      kind: stopped ? "idle" : paused ? "waiting" : active ? "running" : "idle",
      active, paused, cycle, page: currentPage
    };
  }

  async function checkpoint() {
    while (paused && !stopped) {
      await new Promise(resolve => pauseWaiters.push(resolve));
    }
    if (stopped) throw new Error("Stopped by user");
  }

  async function wait(ms) {
    const end = Date.now() + ms;
    while (Date.now() < end) {
      await checkpoint();
      await sleep(Math.min(250, end - Date.now()));
    }
  }

  function matchesManualTarget(target, description) {
    if (!(target instanceof Element)) return false;
    const text = (target.closest("button, label, [role='tab'], [role='button']")?.textContent || target.textContent || "").trim();

    if (description.includes("checkbox")) {
      return !!target.closest('label, [role="checkbox"]') ||
        target.matches('input[type="checkbox"]');
    }
    if (description.includes("Net New")) return text.startsWith("Net New");
    if (description.includes("Total")) return text.startsWith("Total");
    if (description.includes("Apply")) return text === "Apply";
    if (description.includes("Save Accounts")) return text.includes("Save Accounts");
    if (description.includes("Save button")) return text === "Save";
    if (description.includes("Next")) {
      return text === "Next" || !!target.closest('button[aria-label="Next"]') ||
        !!target.closest("button")?.querySelector("i.apollo-icon-chevron-arrow-right");
    }
    return false;
  }

  async function manualRecovery(description, finder, timeout = 15000) {
    let el = finder();
    const deadline = Date.now() + timeout;

    while (!el && Date.now() < deadline) {
      await checkpoint();
      await sleep(500);
      el = finder();
    }
    if (el) return {element: el, manual: false};

    report(`${description} not detected. Click it manually in the Apollo page to continue.`, "Waiting for your click", "waiting");

    await new Promise((resolve, reject) => {
      let finished = false;
      const timer = setInterval(async () => {
        if (stopped) {
          clearInterval(timer);
          document.removeEventListener("click", onClick, true);
          reject(new Error("Stopped by user"));
          return;
        }
        if (paused) return;
        const found = finder();
        if (found) {
          // If it has appeared without a matching click, keep waiting for the user's action.
        }
      }, 400);

      const onClick = event => {
        const target = event.target instanceof Element ? event.target : null;
        if (!target || !matchesManualTarget(target, description)) return;
        if (finished) return;
        finished = true;
        clearInterval(timer);
        document.removeEventListener("click", onClick, true);
        resolve();
      };

      document.addEventListener("click", onClick, true);
    });

    await wait(500);
    report(`Manual click detected for ${description}. Continuing.`, "Running", "running");
    return {element: finder(), manual: true};
  }

  async function requiredAction(description, finder, timeout = 15000) {
    return manualRecovery(description, finder, timeout);
  }

  async function clickRequired(description, finder, timeout = 15000) {
    const result = await requiredAction(description, finder, timeout);
    if (!result.manual && result.element) {
      result.element.click();
      return true;
    }
    // User has already clicked the missing control manually.
    return true;
  }

  async function runLoop() {
    try {
      while (!stopped) {
        cycle++;
        currentPage = "1";
        report(`Cycle ${cycle}: waiting 3 seconds for results…`, "Running", "running");
        await wait(3000);

        for (let page = 1; page <= TOTAL_PAGES; page++) {
          await checkpoint();
          currentPage = String(page);
          report(`Cycle ${cycle}: processing page ${page} of ${TOTAL_PAGES}.`, "Running", "running");

          const checkboxResult = await requiredAction(
            "Row-selection checkbox", findCheckbox, 15000
          );
          if (!checkboxResult.manual && checkboxResult.element && !checkboxResult.element.checked) {
            checkboxResult.element.click();
          }
          await wait(1200);

          const applyButton = findVisibleButton("Apply");
          if (applyButton) {
            applyButton.click();
            report("Apply clicked. Waiting for update…", "Running", "running");
            await wait(1500);
          }

          const saveResult = await requiredAction("Save button", findSaveButton, 30000);
          if (!saveResult.manual && saveResult.element) {
            saveResult.element.click();
          }
          await wait(1000);

          const confirmResult = await requiredAction(
            "Save Accounts button", findSaveAccountsButton, 30000
          );
          if (!confirmResult.manual && confirmResult.element) {
            confirmResult.element.click();
          }

          report(`Page ${page}: save submitted. Waiting 4 seconds…`, "Running", "running");
          await wait(4000);

          if (page < TOTAL_PAGES) {
            const nextResult = await requiredAction("Next page button", findNextButton, 15000);
            if (!nextResult.manual && nextResult.element) {
              nextResult.element.click();
            }
            await wait(3000);
          }
        }

        await checkpoint();
        currentPage = "5 complete";
        report(`Cycle ${cycle}: all 5 pages complete. Clicking Total…`, "Running", "running");

        const totalResult = await requiredAction("Total tab", findTotalTab, 15000);
        if (!totalResult.manual && totalResult.element) totalResult.element.click();

        report("Total selected. Waiting 5 seconds…", "Running", "running");
        await wait(5000);

        const netNewResult = await requiredAction("Net New tab", findNetNewTab, 15000);
        if (!netNewResult.manual && netNewResult.element) netNewResult.element.click();

        report("Net New selected. Waiting 3 seconds before next cycle…", "Running", "running");
        await wait(3000);
      }
    } catch (error) {
      if (error.message !== "Stopped by user") {
        report(`Automation error: ${error.message}`, "Error", "error");
      }
    } finally {
      active = false;
      if (stopped) report("Stopped by user.", "Stopped", "idle");
      else report("Automation finished.", "Ready", "idle");
    }
  }
})();