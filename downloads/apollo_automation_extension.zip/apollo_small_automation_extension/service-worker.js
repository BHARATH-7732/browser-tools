chrome.action.onClicked.addListener(async (tab) => {
  if (!tab || !tab.id || !tab.url || !tab.url.includes("apollo.io")) {
    return;
  }

  const url = chrome.runtime.getURL(`panel.html?tabId=${tab.id}`);
  await chrome.windows.create({
    url,
    type: "popup",
    width: 370,
    height: 570,
    focused: true
  });
});

// Relay status from a content script to the small panel, tagging the source tab.
chrome.runtime.onMessage.addListener((message, sender) => {
  if (message && message.type === "automationStatus" && sender.tab && sender.tab.id !== undefined) {
    chrome.runtime.sendMessage({
      type: "automationStatus",
      tabId: sender.tab.id,
      payload: message.payload
    }).catch(() => {});
  }
});