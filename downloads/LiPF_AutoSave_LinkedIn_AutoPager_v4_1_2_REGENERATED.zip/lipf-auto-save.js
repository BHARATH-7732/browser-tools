(() => {
  if (window.__lipfCombinedPanelInstalled) return;
  window.__lipfCombinedPanelInstalled = true;

  const host = document.createElement('div');
  host.id = 'lipf-auto-save-controller';
  host.style.cssText = 'position:fixed;right:16px;top:16px;z-index:2147483647;';
  const shadow = host.attachShadow({mode:'open'});
  shadow.innerHTML = `
    <style>
      .panel{font:13px/1.4 Arial,sans-serif;color:#17202a;background:#fff;border:1px solid #cbd5e1;border-radius:10px;box-shadow:0 5px 24px #0002;padding:12px;width:250px;max-height:78vh;overflow:auto}
      .title{font-weight:700;font-size:14px;margin-bottom:9px}
      label{display:block;margin-bottom:5px;color:#475569}
      input{box-sizing:border-box;width:100%;padding:7px;border:1px solid #cbd5e1;border-radius:6px;margin-bottom:9px}
      .buttons{display:flex;gap:8px}
      button{flex:1;border:0;border-radius:6px;padding:8px;cursor:pointer;font-weight:600}
      #saveStart,#pagerStart{background:#1769e0;color:white}
      #saveStop,#pagerStop{background:#e5e7eb;color:#111827}
      .status{margin-top:7px;color:#475569;min-height:16px;font-size:12px}
      .note{margin-top:6px;color:#64748b;font-size:11px}
      .section{border-top:1px solid #e2e8f0;padding-top:10px;margin-top:10px}
      .section-title{font-weight:700;font-size:13px;margin-bottom:8px}
    </style>
    <div class="panel">
      <div class="title">LiPF + LinkedIn Automation</div>
      <div class="section" style="border-top:0;padding-top:0;margin-top:0">
        <div class="section-title">LiPF Auto Save</div>
        <label for="saveSeconds">Wait after each save (seconds)</label>
        <input id="saveSeconds" type="number" min="1" max="3600" value="10">
        <div class="buttons"><button id="saveStart">Start</button><button id="saveStop">Stop</button></div>
        <div id="saveStatus" class="status" role="status">Stopped</div>
        <div class="note">Clicks only LiPF's Save button.</div>
      </div>
      <div class="section">
        <div class="section-title">LinkedIn Auto Pager</div>
        <label for="pagerSeconds">Wait before each Next click (seconds)</label>
        <input id="pagerSeconds" type="number" min="1" max="3600" value="10">
        <div class="buttons"><button id="pagerStart">Start Pager</button><button id="pagerStop">Stop Pager</button></div>
        <div id="pagerStatus" class="status" role="status">Stopped</div>
        <div class="note">Works on LinkedIn search result pages with a Next control.</div>
      </div>
    </div>`;
  (document.body || document.documentElement).appendChild(host);
  const $ = id => shadow.getElementById(id);
  const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));

  // LiPF AutoSave
  let saveRunning = false, saveToken = 0;
  function findSaveButton(label) {
    return [...document.querySelectorAll('button')].find(button => {
      const content = button.querySelector('.lipf-btn__content');
      const text = (content?.textContent || button.textContent || '').trim();
      return text === label && !button.disabled && button.getAttribute('aria-disabled') !== 'true';
    });
  }
  async function runSave(token) {
    $('saveStatus').textContent = 'Looking for Save…';
    while (saveRunning && token === saveToken) {
      const saveButton = findSaveButton('Save');
      if (!saveButton) { await sleep(500); continue; }
      saveButton.click();
      $('saveStatus').textContent = 'Clicked Save; waiting for confirmation…';
      while (saveRunning && token === saveToken && !findSaveButton('Go to list')) await sleep(300);
      if (!saveRunning || token !== saveToken) break;
      const seconds = Math.max(1, Math.min(3600, Number($('saveSeconds').value) || 10));
      for (let left = seconds; left > 0 && saveRunning && token === saveToken; left--) {
        $('saveStatus').textContent = `Saved. Next check in ${left}s`;
        await sleep(1000);
      }
    }
    if (token === saveToken) $('saveStatus').textContent = 'Stopped';
  }
  $('saveStart').addEventListener('click', () => {
    if (saveRunning) return;
    saveRunning = true;
    const token = ++saveToken;
    runSave(token).catch(error => {
      saveRunning = false;
      $('saveStatus').textContent = 'Error: ' + error.message;
    });
  });
  $('saveStop').addEventListener('click', () => {
    saveRunning = false; ++saveToken;
    $('saveStatus').textContent = 'Stopped';
  });

  // LinkedIn Auto Pager: execute in the active LinkedIn tab, not in the side-panel document.
  let pagerRunning = false, pagerTimer = null, pagerBusy = false, pageCount = 0;
  async function clickNextInLinkedInTab() {
    const tabs = await chrome.tabs.query({active:true, lastFocusedWindow:true});
    const tab = tabs && tabs[0];
    if (!tab || !tab.id || !/^https:\/\/([a-z0-9-]+\.)?linkedin\.com\//i.test(tab.url || '')) {
      return {ok:false, reason:'Open a LinkedIn search results tab first.'};
    }
    const injected = await chrome.scripting.executeScript({
      target:{tabId:tab.id},
      func:() => {
        const items = [...document.querySelectorAll('button,a,[role="button"]')];
        const next = items.find(el => {
          const text = (el.innerText || el.textContent || '').trim().replace(/\s+/g,' ');
          const aria = (el.getAttribute('aria-label') || '').trim();
          const title = (el.getAttribute('title') || '').trim();
          const matches = /^next(?:\s+page)?$/i.test(text) ||
            /^next(?:\s+page)?$/i.test(aria) || /^next(?:\s+page)?$/i.test(title);
          const disabled = el.disabled || el.getAttribute('aria-disabled') === 'true' ||
            el.classList.contains('artdeco-button--disabled');
          return matches && !disabled && el.getClientRects().length > 0;
        });
        if (!next) return {ok:false, reason:'Next page control not found on this LinkedIn page.'};
        next.click();
        return {ok:true};
      }
    });
    return injected?.[0]?.result || {ok:false, reason:'Could not access the LinkedIn page.'};
  }
  async function pagerTick() {
    if (!pagerRunning || pagerBusy) return;
    pagerBusy = true;
    try {
      const result = await clickNextInLinkedInTab();
      if (!result.ok) {
        $('pagerStatus').textContent = result.reason + ' Pager stopped.';
        stopPager(false);
      } else {
        pageCount++;
        $('pagerStatus').textContent = `Clicked Next ${pageCount} time${pageCount === 1 ? '' : 's'}.`;
      }
    } catch (error) {
      $('pagerStatus').textContent = 'Pager error: ' + error.message;
      stopPager(false);
    } finally {
      pagerBusy = false;
    }
  }
  function startPager() {
    if (pagerRunning) return;
    const seconds = Math.max(1, Math.min(3600, Number($('pagerSeconds').value) || 10));
    pagerRunning = true;
    pageCount = 0;
    $('pagerStatus').textContent = `Running. First Next click in ${seconds}s.`;
    pagerTimer = setInterval(pagerTick, seconds * 1000);
  }
  function stopPager(update = true) {
    pagerRunning = false;
    if (pagerTimer) clearInterval(pagerTimer);
    pagerTimer = null;
    if (update) $('pagerStatus').textContent = 'Stopped';
  }
  $('pagerStart').addEventListener('click', startPager);
  $('pagerStop').addEventListener('click', () => stopPager(true));
})();
