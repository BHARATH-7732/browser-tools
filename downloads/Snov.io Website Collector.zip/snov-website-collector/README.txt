Snov.io Website Collector — v1.1.0

Install in Chrome:
1. Extract this folder from the ZIP.
2. Open chrome://extensions.
3. Turn on Developer mode.
4. Click Load unpacked and select the snov-website-collector folder.
5. Open an app.snov.io Companies list, click the extension, choose a page count, and start.

0 pages means collect until the last available page. Keep the popup open until the CSV download begins.

The popup redesign and extension icons are included. The collector's website-only CSV output is preserved.
