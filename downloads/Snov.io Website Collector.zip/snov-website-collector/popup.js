const FIELDS = ["Website"];

const startBtn = document.getElementById("startBtn");
const stopBtn = document.getElementById("stopBtn");
const statusEl = document.getElementById("status");
const statusTitle = document.getElementById("statusTitle");
const statusDot = document.getElementById("statusDot");
const progressBar = document.getElementById("progressBar");
const pagesInput = document.getElementById("pagesInput");

function setStatus(title, message, progress = null, mode = "ready") {
  statusTitle.textContent = title;
  statusEl.textContent = message;
  statusDot.style.background = mode === "error" ? "#f16b78" : mode === "working" ? "#38c8f4" : "#45d49a";
  statusDot.style.boxShadow = mode === "error" ? "0 0 0 3px #f16b7820" : mode === "working" ? "0 0 0 3px #38c8f420" : "0 0 0 3px #45d49a20";
  if (progress !== null) progressBar.style.width = `${Math.max(0, Math.min(100, progress))}%`;
}

function downloadCSV(data) {
  if (!data || !data.length) return;
  const escapeCSV = (val) => `"${String(val ?? "").replace(/"/g, '""')}"`;
  const rows = data.map((row) => row.Website?.trim()).filter(Boolean).map(escapeCSV);
  const csvContent = "\uFEFF" + ['"Website"', ...rows].join("\n");
  const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `snov_websites_${Date.now()}.csv`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === "SCRAPE_PROGRESS") {
    const total = Number(msg.totalPages);
    const percent = Number.isFinite(total) && total > 0 ? (msg.currentPage / total) * 100 : 0;
    setStatus("Collecting websites", `Page ${msg.currentPage}/${msg.totalPages} · ${msg.count} websites collected so far.`, percent, "working");
  } else if (msg.type === "SCRAPE_DONE") {
    const collectedData = msg.data || [];
    startBtn.disabled = false;
    stopBtn.disabled = true;
    if (collectedData.length > 0) {
      downloadCSV(collectedData);
      setStatus("Export complete", `${collectedData.length} websites collected across ${msg.pagesScraped} page(s). Your CSV download is ready.`, 100);
    } else {
      setStatus("No websites found", "The collector finished, but no website entries were found on the scanned pages.", 0);
    }
  } else if (msg.type === "SCRAPE_ERROR") {
    setStatus("Something went wrong", msg.error || "The collection could not be completed.", 0, "error");
    startBtn.disabled = false;
    stopBtn.disabled = true;
  }
});

startBtn.addEventListener("click", async () => {
  const rawVal = pagesInput.value.trim();
  const totalPages = rawVal === "" ? 0 : parseInt(rawVal, 10);
  if (!Number.isInteger(totalPages) || totalPages < 0 || totalPages > 500) {
    setStatus("Check page limit", "Enter a number from 0 to 500. Use 0 to collect all pages.", 0, "error");
    return;
  }

  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.url?.includes("app.snov.io")) {
      setStatus("Snov.io tab required", "Open an app.snov.io Companies list in the active tab, then try again.", 0, "error");
      return;
    }

    startBtn.disabled = true;
    stopBtn.disabled = false;
    progressBar.style.width = "0%";
    setStatus("Starting collection", "Keep this popup open while the pages are scanned and the CSV is prepared.", 0, "working");

    await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ["content.js"] });
    chrome.tabs.sendMessage(tab.id, { action: "START_SCRAPE", totalPages, fields: FIELDS });
  } catch (error) {
    startBtn.disabled = false;
    stopBtn.disabled = true;
    setStatus("Could not start", error?.message || "Check that the Snov.io page is open and try again.", 0, "error");
  }
});

stopBtn.addEventListener("click", async () => {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab) chrome.tabs.sendMessage(tab.id, { action: "STOP_SCRAPE" });
    setStatus("Stopping collection", "The collector is stopping and will export the websites gathered so far.", null, "working");
    stopBtn.disabled = true;
  } catch (error) {
    setStatus("Could not stop", error?.message || "Try closing and reopening the popup.", null, "error");
  }
});
