(() => {
  if (window.__snovCollectorInjected) return;
  window.__snovCollectorInjected = true;

  let stopRequested = false;

  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  function getTableRows() {
    const trs = Array.from(document.querySelectorAll("table tbody tr"));
    if (trs.length > 0) return trs;

    const linkAnchors = Array.from(document.querySelectorAll('a[href^="http"]')).filter((a) => {
      const text = a.textContent.trim();
      return text.startsWith("http://") || text.startsWith("https://");
    });
    return linkAnchors
      .map((a) => a.closest("tr, [class*='row'], [class*='item']"))
      .filter(Boolean);
  }

  function extractPageData(fields) {
    const rows = getTableRows();
    const pageResults = [];

    for (const row of rows) {
      const cells = Array.from(row.querySelectorAll("td, [class*='cell'], [class*='col']"));
      const rowObj = {};

      const websiteLink = row.querySelector('a[href^="http"]');
      const websiteText = websiteLink ? websiteLink.textContent.trim() : "";

      const textCells = cells
        .map((c) => c.innerText.trim())
        .filter((t) => t.length > 0);

      const webIdx = textCells.findIndex(
        (t) => t.includes("http://") || t.includes("https://")
      );

      if (webIdx !== -1) {
        rowObj.Company = webIdx > 0 ? textCells[webIdx - 1] : "";
        rowObj.Website = textCells[webIdx] || websiteText;
        rowObj.Industry = textCells[webIdx + 1] || "";
        rowObj.Emails = textCells[webIdx + 2] || "0";
        rowObj.Prospects = textCells[webIdx + 3] || "0";
      } else if (textCells.length >= 5) {
        rowObj.Company = textCells[0];
        rowObj.Website = websiteText || textCells[1];
        rowObj.Industry = textCells[2];
        rowObj.Emails = textCells[3];
        rowObj.Prospects = textCells[4];
      } else {
        continue;
      }

      const filtered = {};
      for (const f of fields) {
        filtered[f] = rowObj[f] ?? "";
      }
      pageResults.push(filtered);
    }

    return pageResults;
  }

  function getFirstRowSignature() {
    const rows = getTableRows();
    return rows.length ? rows[0].innerText.trim() : "";
  }

  // Finds Snov.io's bottom pagination bar and clicks the next page
  function goToNextPage(currentPageNumber) {
    const targetPageStr = String(currentPageNumber + 1);

    // 1. Find the pagination container near the bottom of the main list (contains "1", "2", "3"...)
    const allClickables = Array.from(
      document.querySelectorAll("button, a, li, span, div")
    ).filter((el) => {
      if (!el.offsetParent) return false;
      const rect = el.getBoundingClientRect();
      // Pagination bar sits near the bottom half of the viewport
      return rect.top > window.innerHeight * 0.6 && rect.height > 16 && rect.height < 60;
    });

    // 2. First try clicking the exact next page number button (e.g., "2", "3", "4"...)
    const exactPageBtn = allClickables.find((el) => {
      return el.children.length === 0 && el.textContent.trim() === targetPageStr;
    });

    if (exactPageBtn) {
      exactPageBtn.click();
      return true;
    }

    // 3. Fallback: Find the pagination bar containing page "1" and click its last button (the '>' arrow)
    const pageOneEl = allClickables.find(
      (el) => el.children.length === 0 && el.textContent.trim() === "1"
    );

    if (pageOneEl) {
      // Walk up to the pagination container holding all page items
      let container = pageOneEl.parentElement;
      for (let i = 0; i < 4 && container; i++) {
        const items = Array.from(container.querySelectorAll("button, a, li")).filter(
          (el) => el.offsetParent !== null
        );
        if (items.length >= 3) {
          const nextArrowBtn = items[items.length - 1];
          const isDisabled =
            nextArrowBtn.disabled ||
            nextArrowBtn.getAttribute("disabled") !== null ||
            nextArrowBtn.classList.contains("disabled") ||
            nextArrowBtn.getAttribute("aria-disabled") === "true";

          if (!isDisabled) {
            nextArrowBtn.click();
            return true;
          }
          return false;
        }
        container = container.parentElement;
      }
    }

    return false;
  }

  async function waitForPageLoad(previousSig, timeoutMs = 15000) {
    const start = Date.now();
    // Wait until the first row changes from the previous page's first row
    while (Date.now() - start < timeoutMs) {
      if (stopRequested) return false;
      await sleep(400);
      const currentSig = getFirstRowSignature();
      if (currentSig && currentSig !== previousSig) {
        // Wait an extra 1.2s so all 200 rows finish rendering in the DOM
        await sleep(1200);
        return true;
      }
    }
    return false;
  }

  async function runScraper(totalPages, fields) {
    stopRequested = false;
    const allResults = [];
    const seenKeys = new Set();
    let pagesScraped = 0;

    // If totalPages is 0 or empty, run until the last page automatically
    const maxPages = totalPages > 0 ? totalPages : 9999;

    for (let page = 1; page <= maxPages; page++) {
      if (stopRequested) break;

      // Ensure table rows are present before extracting
      await sleep(500);
      const rows = extractPageData(fields);

      for (const item of rows) {
        const key = JSON.stringify(item);
        if (!seenKeys.has(key)) {
          seenKeys.add(key);
          allResults.push(item);
        }
      }

      pagesScraped = page;
      chrome.runtime.sendMessage({
        type: "SCRAPE_PROGRESS",
        currentPage: page,
        totalPages: totalPages > 0 ? totalPages : "End",
        count: allResults.length
      });

      if (page >= maxPages || stopRequested) break;

      const prevSig = getFirstRowSignature();
      const clicked = goToNextPage(page);
      if (!clicked) {
        // Reached the final page
        break;
      }

      const loaded = await waitForPageLoad(prevSig);
      if (!loaded) {
        break;
      }
    }

    chrome.runtime.sendMessage({
      type: "SCRAPE_DONE",
      data: allResults,
      pagesScraped
    });
  }

  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.action === "START_SCRAPE") {
      runScraper(msg.totalPages, msg.fields);
    } else if (msg.action === "STOP_SCRAPE") {
      stopRequested = true;
    }
  });
})();