(() => {
  if (window.__lipfSequentialAutomationInstalled) return;
  window.__lipfSequentialAutomationInstalled = true;

  const host = document.createElement('div');
  host.id = 'schemareach-start-stop-float';
  host.style.cssText = 'position:fixed;right:10px;top:8px;z-index:2147483647;';
  const shadow = host.attachShadow({mode:'open'});
  shadow.innerHTML = `
    <style>
      .bar{display:flex;gap:8px;width:100%;box-sizing:border-box;padding:5px;background:#fff;border:1px solid #d9dce5;border-radius:12px;box-shadow:0 3px 14px #0002}
      button{flex:1;min-width:0;border:0;border-radius:8px;padding:11px 12px;cursor:pointer;font:700 13px Arial,sans-serif;letter-spacing:.2px}
      #start{background:#2468e8;color:#fff}
      #stop{background:#eeeef3;color:#242633}
      button:disabled{opacity:.55;cursor:default}
    </style>
    <div class="bar" title="Drag this small control bar to reposition it">
      <button id="start" type="button">START</button>
      <button id="stop" type="button">STOP</button>
    </div>`;
  const mountHost = () => { if (!host.isConnected) (document.body || document.documentElement).appendChild(host); };
  if (document.body) mountHost(); else document.addEventListener('DOMContentLoaded', mountHost, {once:true});
  const $ = id => shadow.getElementById(id);
  // Drag the compact two-button control without adding any extra visible controls.
  const bar = shadow.querySelector('.bar');
  let drag = null;
  bar.addEventListener('pointerdown', event => {
    if (event.target?.tagName === 'BUTTON') return;
    const rect = host.getBoundingClientRect();
    drag = {x:event.clientX, y:event.clientY, left:rect.left, top:rect.top};
    bar.setPointerCapture?.(event.pointerId);
  });
  bar.addEventListener('pointermove', event => {
    if (!drag) return;
    const left = Math.max(0, Math.min(window.innerWidth - host.offsetWidth, drag.left + event.clientX - drag.x));
    const top = Math.max(0, Math.min(window.innerHeight - host.offsetHeight, drag.top + event.clientY - drag.y));
    host.style.left = left + 'px';
    host.style.top = top + 'px';
    host.style.right = 'auto';
  });
  bar.addEventListener('pointerup', () => { drag = null; });
  bar.addEventListener('pointercancel', () => { drag = null; });
  const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
  let running = false, runToken = 0, savedCount = 0, skippedCount = 0, failedCount = 0, pageCount = 1;

  function setStatus(message) { statusText = String(message || ''); host.title = statusText; }
  function updateStats() {}
  let statusText = 'Ready';
  function setStatus(message) { statusText = String(message || ''); host.title = statusText; }
  function updateStats() {}

  function getSaveButton() {
    return [...document.querySelectorAll('button.lipf-btn, button')].find(button => {
      const content = button.querySelector('.lipf-btn__content');
      const text = (content?.textContent || button.textContent || '').replace(/\s+/g, ' ').trim();
      return text === 'Save' && button.getClientRects().length > 0;
    }) || null;
  }

  function isSaveButtonReady(button) {
    if (!button || !button.isConnected || button.getClientRects().length === 0) return false;
    const ariaDisabled = button.getAttribute('aria-disabled') === 'true';
    const ariaBusy = button.getAttribute('aria-busy') === 'true';
    const classDisabled = button.classList.contains('lipf-btn--disabled') ||
      button.classList.contains('lipf-btn--loading');
    return !button.disabled && !ariaDisabled && !ariaBusy && !classDisabled;
  }

  async function waitForSaveButton(token) {
    setStatus(`Page ${pageCount}: waiting for LiPF Save button to be ready…`);
    while (running && token === runToken) {
      const button = getSaveButton();
      if (isSaveButtonReady(button)) return button;
      await sleep(400);
    }
    return null;
  }

  async function processCurrentPage(token) {
    const button = await waitForSaveButton(token);
    if (!button || !running || token !== runToken) return 'stopped';

    // Click LiPF Save once on each loaded page. No colour checks, verification, or retries.
    const currentButton = getSaveButton();
    if (!isSaveButtonReady(currentButton)) {
      setStatus('LiPF Save button is not ready yet. Waiting for it to become enabled…');
      const readyButton = await waitForSaveButton(token);
      if (!readyButton || !running || token !== runToken) return 'stopped';
      setStatus('Clicking Save…');
      readyButton.click();
    } else {
      setStatus('Clicking Save…');
      currentButton.click();
    }
    savedCount++;
    updateStats();

    // Allow LiPF 3.5 seconds to finish its save action before navigating.
    setStatus('Save clicked. Waiting 3.5 seconds before the next page…');
    await sleep(3500);
    if (!running || token !== runToken) return 'stopped';

    setStatus('Save wait complete. Moving to the next LinkedIn page…');
    return 'saved';
  }

  async function getLinkedInTab() {
    const tabs = await chrome.tabs.query({active:true, lastFocusedWindow:true});
    const tab = tabs && tabs[0];
    if (!tab?.id || !/^https:\/\/([a-z0-9-]+\.)?linkedin\.com\//i.test(tab.url || '')) {
      throw new Error('Select your LinkedIn search results tab, then start again.');
    }
    return tab;
  }
  async function getPageSignature(tabId) {
    const result = await chrome.scripting.executeScript({
      target:{tabId},
      func:() => {
        const active = document.querySelector('button[aria-current="page"], a[aria-current="page"], .artdeco-pagination__indicator--number.active');
        const text = document.querySelector('main')?.innerText?.slice(0,1200) || document.body.innerText.slice(0,1200);
        return {url:location.href, active:active?.textContent?.trim() || '', text};
      }
    });
    return result?.[0]?.result || null;
  }
  async function clickNextAndWait(token) {
    const tab = await getLinkedInTab();
    const before = await getPageSignature(tab.id);
    const result = await chrome.scripting.executeScript({
      target:{tabId:tab.id},
      func:() => {
        const els = [...document.querySelectorAll('button,a,[role="button"]')];
        const next = els.find(el => {
          const txt = (el.innerText || el.textContent || '').trim().replace(/\s+/g,' ');
          const aria = (el.getAttribute('aria-label') || '').trim();
          const title = (el.getAttribute('title') || '').trim();
          const match = /^next(?:\s+page)?$/i.test(txt) || /^next(?:\s+page)?$/i.test(aria) || /^next(?:\s+page)?$/i.test(title);
          const disabled = el.disabled || el.getAttribute('aria-disabled') === 'true' || el.classList.contains('artdeco-button--disabled');
          return match && !disabled && el.getClientRects().length > 0;
        });
        if (!next) return {ok:false, reason:'No enabled Next button. This may be the last page.'};
        next.click();
        return {ok:true};
      }
    });
    const clickResult = result?.[0]?.result;
    if (!clickResult?.ok) return clickResult || {ok:false,reason:'Could not click Next.'};
    setStatus('Clicked Next. Waiting for the next page to load…');
    const maxWait = 45000;
    const deadline = Date.now() + maxWait;
    while (running && token === runToken && Date.now() < deadline) {
      await sleep(1000);
      const current = await getPageSignature(tab.id);
      if (current && before && (current.url !== before.url || current.active !== before.active || current.text !== before.text)) {
        // Wait briefly for result rendering to settle.
        await sleep(1200);
        return {ok:true};
      }
    }
    return {ok:false,reason:'LinkedIn page change could not be verified. Paused to avoid skipping prospects.'};
  }

  async function run(token) {
    try {
      await getLinkedInTab();
      while (running && token === runToken) {
        const outcome = await processCurrentPage(token);
        if (outcome === 'stopped') return;
        if (outcome !== 'saved') {
          running = false;
          return;
        }

        if (!running || token !== runToken) return;
        setStatus('Clicking LinkedIn Next…');
        const nextResult = await clickNextAndWait(token);
        if (!nextResult.ok) {
          setStatus(nextResult.reason + ' Automation stopped.');
          running = false;
          return;
        }
        pageCount++;
        updateStats();
        setStatus(`Page ${pageCount} loaded. Waiting for LiPF Save button…`);
      }
    } catch (error) {
      setStatus(error.message || String(error));
      running = false;
    }
  }

  $('start').addEventListener('click', () => {
    if (running) return;
    running = true;
    const token = ++runToken;
    setStatus('Sequential automation started.');
    run(token);
  });
  $('stop').addEventListener('click', () => {
    running = false;
    ++runToken;
    setStatus('Stopped by user. No further page navigation will occur.');
  });
  updateStats();
})();
