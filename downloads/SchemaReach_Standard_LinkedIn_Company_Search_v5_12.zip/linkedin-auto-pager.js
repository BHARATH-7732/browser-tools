(() => {
  if (window.__linkedinAutoPagerInstalled) return;
  window.__linkedinAutoPagerInstalled = true;

  let running = false;
  let timerId = null;
  let secondsBetweenClicks = 10;
  let pageNumber = 1;

  const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));

  function findNextButton() {
    // LinkedIn's pagination control may be a button or link and its label varies.
    const candidates = [...document.querySelectorAll(
      'button, a, [role="button"]'
    )];

    return candidates.find(el => {
      const text = (el.innerText || el.textContent || "").trim().replace(/\s+/g, " ");
      const aria = (el.getAttribute("aria-label") || "").trim();
      const title = (el.getAttribute("title") || "").trim();
      const isNext = /^next(?:\s+page)?$/i.test(text) ||
                     /^next(?:\s+page)?$/i.test(aria) ||
                     /^next(?:\s+page)?$/i.test(title);
      const disabled = el.disabled ||
        el.getAttribute("aria-disabled") === "true" ||
        el.classList.contains("artdeco-button--disabled");
      return isNext && !disabled && el.getClientRects().length > 0;
    });
  }

  async function runLoop() {
    while (running) {
      const button = findNextButton();

      if (!button) {
        running = false;
        console.info("[LinkedIn Auto Pager] Next page control not found. Stopped.");
        break;
      }

      console.info(`[LinkedIn Auto Pager] Page ${pageNumber}. Waiting ${secondsBetweenClicks}s.`);
      await sleep(secondsBetweenClicks * 1000);
      if (!running) break;

      // Re-find the control after waiting in case LinkedIn re-rendered the page.
      const currentButton = findNextButton();
      if (!currentButton) {
        running = false;
        console.info("[LinkedIn Auto Pager] Next page control disappeared. Stopped.");
        break;
      }

      currentButton.click();
      pageNumber++;
      console.info(`[LinkedIn Auto Pager] Clicked Next (page ${pageNumber}).`);

      // Allow LinkedIn time to update the results before looking for Next again.
      await sleep(2500);
    }

    if (timerId) clearTimeout(timerId);
    timerId = null;
  }

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === "START") {
      const seconds = Number(message.seconds);
      if (!Number.isFinite(seconds) || seconds < 1 || seconds > 3600) {
        sendResponse({ message: "Choose a wait time from 1 to 3600 seconds." });
        return;
      }
      secondsBetweenClicks = seconds;
      if (!running) {
        running = true;
        pageNumber = 1;
        runLoop();
      }
      sendResponse({ message: `Started. Waiting ${secondsBetweenClicks} seconds before each Next click.` });
      return true;
    }

    if (message.action === "STOP") {
      running = false;
      if (timerId) clearTimeout(timerId);
      timerId = null;
      sendResponse({ message: "Stopped. No more Next clicks will be made." });
      return true;
    }
  });
})();