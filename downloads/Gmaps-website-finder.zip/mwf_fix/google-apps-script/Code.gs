/**
 * Maps Website Finder - Google Apps Script Web App receiver
 *
 * Auto-sync receiver for 500-lead batches.
 *
 * ONE spreadsheet -> ONE sheet per keyword.
 * Each keyword sheet contains ONLY:
 * Country | Target City | Search Query | Company Name | Category | Website | keyword
 */

const HEADERS = [
  "Country",
  "Target City",
  "Search Query",
  "Company Name",
  "Category",
  "Website",
  "keyword"
];

function doPost(e) {
  const lock = LockService.getScriptLock();

  if (!lock.tryLock(30000)) {
    return jsonResponse({
      status: "error",
      message: "Server busy. Try again."
    });
  }

  try {
    if (!e || !e.postData || !e.postData.contents) {
      return jsonResponse({
        status: "error",
        message: "No data received."
      });
    }

    let payload;

    try {
      payload = JSON.parse(e.postData.contents);
    } catch (err) {
      return jsonResponse({
        status: "error",
        message: "Invalid JSON received."
      });
    }

    const leads = Array.isArray(payload.leads)
      ? payload.leads
      : [];

    if (!leads.length) {
      return jsonResponse({
        status: "success",
        received: 0,
        appended: 0
      });
    }

    const ss = SpreadsheetApp.getActiveSpreadsheet();

    if (!ss) {
      return jsonResponse({
        status: "error",
        message: "Spreadsheet not found."
      });
    }

    const fallbackKeyword = cleanKeyword(
      payload.keyword || payload.Keyword || ""
    );

    const fallbackCountry = cleanValue(
      payload.country || payload.Country || ""
    );

    // Group the 500-lead batch by keyword.
    const groups = {};

    leads.forEach(function (lead) {
      if (!lead || typeof lead !== "object") return;

      const keyword = getLeadKeyword(
        lead,
        fallbackKeyword
      );

      if (!keyword) return;

      const key = normalizeKeyword(keyword);

      if (!groups[key]) {
        groups[key] = {
          keyword: keyword,
          leads: []
        };
      }

      groups[key].leads.push(lead);
    });

    if (!Object.keys(groups).length) {
      return jsonResponse({
        status: "error",
        message: "No keyword found in received leads."
      });
    }

    const results = [];
    let totalAppended = 0;
    let totalDuplicates = 0;

    Object.keys(groups).forEach(function (key) {
      const group = groups[key];

      const sheet = getOrCreateKeywordSheet(
        ss,
        group.keyword
      );

      const result = appendLeads(
        sheet,
        group.leads,
        group.keyword,
        fallbackCountry
      );

      totalAppended += result.appended;
      totalDuplicates += result.skippedDuplicates;

      results.push({
        keyword: group.keyword,
        sheet: sheet.getName(),
        received: group.leads.length,
        appended: result.appended,
        skippedDuplicates: result.skippedDuplicates
      });
    });

    return jsonResponse({
      status: "success",
      received: leads.length,
      appended: totalAppended,
      skippedDuplicates: totalDuplicates,
      sheets: results
    });

  } catch (err) {
    console.error(err);

    return jsonResponse({
      status: "error",
      message: String(err)
    });
  } finally {
    lock.releaseLock();
  }
}

function doGet() {
  return jsonResponse({
    status: "success",
    message: "Maps Website Finder endpoint operational."
  });
}

function getLeadKeyword(lead, fallbackKeyword) {
  const direct = cleanKeyword(
    lead.keyword ||
    lead.Keyword ||
    lead.searchKeyword ||
    lead.SearchKeyword ||
    ""
  );

  if (direct) return direct;

  const query = cleanValue(
    lead["Search Query"] ||
    lead.SearchQuery ||
    lead.Query ||
    lead.query ||
    ""
  );

  if (query) {
    const extracted = extractKeyword(query);
    if (extracted) return extracted;
  }

  return fallbackKeyword;
}

function extractKeyword(query) {
  const value = cleanKeyword(query);
  if (!value) return "";

  const match = value.match(/^(.+?)\s+in\s+.+$/i);

  if (match && match[1]) {
    return cleanKeyword(match[1]);
  }

  return value;
}

function getOrCreateKeywordSheet(ss, keyword) {
  const safeName = makeSafeSheetName(keyword);
  const wanted = safeName.toLowerCase();
  const sheets = ss.getSheets();

  for (let i = 0; i < sheets.length; i++) {
    if (sheets[i].getName().toLowerCase() === wanted) {
      ensureHeaders(sheets[i]);
      return sheets[i];
    }
  }

  const sheet = ss.insertSheet(safeName);
  setupSheet(sheet);
  return sheet;
}

function setupSheet(sheet) {
  sheet.clear();

  sheet
    .getRange(1, 1, 1, HEADERS.length)
    .setValues([HEADERS]);

  formatHeader(sheet);
  sheet.setFrozenRows(1);

  sheet.setColumnWidth(1, 110);
  sheet.setColumnWidth(2, 140);
  sheet.setColumnWidth(3, 240);
  sheet.setColumnWidth(4, 220);
  sheet.setColumnWidth(5, 180);
  sheet.setColumnWidth(6, 300);
  sheet.setColumnWidth(7, 180);
}

function ensureHeaders(sheet) {
  if (sheet.getLastRow() === 0) {
    setupSheet(sheet);
    return;
  }

  const current = sheet
    .getRange(1, 1, 1, HEADERS.length)
    .getValues()[0];

  let different = false;

  for (let i = 0; i < HEADERS.length; i++) {
    if (current[i] !== HEADERS[i]) {
      different = true;
      break;
    }
  }

  if (different) {
    sheet
      .getRange(1, 1, 1, HEADERS.length)
      .setValues([HEADERS]);

    formatHeader(sheet);
  }

  sheet.setFrozenRows(1);
}

function formatHeader(sheet) {
  sheet
    .getRange(1, 1, 1, HEADERS.length)
    .setFontWeight("bold")
    .setBackground("#0f172a")
    .setFontColor("#ffffff")
    .setHorizontalAlignment("center");
}

function appendLeads(sheet, leads, keyword, fallbackCountry) {
  const existingWebsites = getExistingWebsites(sheet);
  const rows = [];
  let skippedDuplicates = 0;

  leads.forEach(function (lead) {
    if (!lead || typeof lead !== "object") return;

    const country = cleanValue(
      lead.Country ||
      lead.country ||
      fallbackCountry
    );

    const targetCity = cleanValue(
      lead["Target City"] ||
      lead.TargetCity ||
      lead.targetCity ||
      lead.City ||
      lead.city ||
      ""
    );

    const searchQuery = cleanValue(
      lead["Search Query"] ||
      lead.SearchQuery ||
      lead.Query ||
      lead.query ||
      ""
    );

    const companyName = cleanValue(
      lead["Company Name"] ||
      lead.CompanyName ||
      lead.companyName ||
      lead.name ||
      lead.Name ||
      ""
    );

    const category = cleanValue(
      lead.Category ||
      lead.category ||
      ""
    );

    const website = cleanValue(
      lead.Website ||
      lead.website ||
      lead.URL ||
      lead.url ||
      ""
    );

    const rowKeyword = cleanKeyword(
      lead.keyword ||
      lead.Keyword ||
      keyword
    );

    if (website) {
      const websiteKey = normalizeWebsite(website);

      if (existingWebsites.has(websiteKey)) {
        skippedDuplicates++;
        return;
      }

      existingWebsites.add(websiteKey);
    }

    rows.push([
      country,
      targetCity,
      searchQuery,
      companyName,
      category,
      website,
      rowKeyword
    ]);
  });

  if (rows.length) {
    sheet
      .getRange(
        sheet.getLastRow() + 1,
        1,
        rows.length,
        HEADERS.length
      )
      .setValues(rows);
  }

  return {
    appended: rows.length,
    skippedDuplicates: skippedDuplicates
  };
}

function getExistingWebsites(sheet) {
  const result = new Set();
  const lastRow = sheet.getLastRow();

  if (lastRow <= 1) return result;

  const values = sheet
    .getRange(2, 6, lastRow - 1, 1)
    .getValues();

  values.forEach(function (row) {
    if (row[0]) {
      result.add(normalizeWebsite(row[0]));
    }
  });

  return result;
}

function normalizeWebsite(value) {
  return String(value || "")
    .trim()
    .toLowerCase()
    .replace(/^https?:\/\//, "")
    .replace(/^www\./, "")
    .replace(/\/$/, "");
}

function cleanValue(value) {
  if (value === null || value === undefined) return "";

  return String(value)
    .trim()
    .replace(/\s+/g, " ");
}

function cleanKeyword(value) {
  return cleanValue(value);
}

function normalizeKeyword(value) {
  return cleanKeyword(value).toLowerCase();
}

function makeSafeSheetName(keyword) {
  let name = cleanKeyword(keyword) || "Unknown Keyword";

  name = name
    .replace(/[:\\\/\?\*\[\]]/g, " ")
    .replace(/\s+/g, " ")
    .trim();

  if (name.length > 100) {
    name = name.substring(0, 100).trim();
  }

  return name || "Unknown Keyword";
}

function jsonResponse(data) {
  return ContentService
    .createTextOutput(JSON.stringify(data))
    .setMimeType(ContentService.MimeType.JSON);
}
