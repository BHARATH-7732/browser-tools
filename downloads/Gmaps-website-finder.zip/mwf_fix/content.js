(async () => {
  "use strict";

  const existingPanel = document.getElementById("gmaps-omni-suite");
  if (existingPanel) existingPanel.remove();

  const COUNTRY_PRESETS = {
    US: [
      "New York, NY", "Los Angeles, CA", "Chicago, IL", "Houston, TX", "Phoenix, AZ",
      "Philadelphia, PA", "San Antonio, TX", "San Diego, CA", "Dallas, TX", "Jacksonville, FL",
      "Austin, TX", "Fort Worth, TX", "San Jose, CA", "Columbus, OH", "Charlotte, NC",
      "Indianapolis, IN", "San Francisco, CA", "Seattle, WA", "Denver, CO", "Oklahoma City, OK",
      "Nashville, TN", "El Paso, TX", "Washington, DC", "Las Vegas, NV", "Boston, MA",
      "Portland, OR", "Louisville, KY", "Memphis, TN", "Detroit, MI", "Baltimore, MD",
      "Milwaukee, WI", "Albuquerque, NM", "Tucson, AZ", "Fresno, CA", "Sacramento, CA",
      "Mesa, AZ", "Kansas City, MO", "Atlanta, GA", "Colorado Springs, CO", "Omaha, NE",
      "Raleigh, NC", "Virginia Beach, VA", "Long Beach, CA", "Miami, FL", "Oakland, CA",
      "Minneapolis, MN", "Tulsa, OK", "Bakersfield, CA", "Tampa, FL", "Wichita, KS",
      "Arlington, TX", "Aurora, CO", "New Orleans, LA", "Cleveland, OH", "Anaheim, CA",
      "Henderson, NV", "Honolulu, HI", "Riverside, CA", "Santa Ana, CA", "Corpus Christi, TX",
      "Lexington, KY", "San Juan, PR", "Stockton, CA", "St. Paul, MN", "Cincinnati, OH",
      "Irvine, CA", "Greensboro, NC", "Pittsburgh, PA", "Lincoln, NE", "St. Louis, MO",
      "Orlando, FL", "Durham, NC", "Plano, TX", "Anchorage, AK", "Newark, NJ",
      "Chula Vista, CA", "Fort Wayne, IN", "St. Petersburg, FL", "Laredo, TX", "Jersey City, NJ",
      "Chandler, AZ", "Madison, WI", "Lubbock, TX", "Scottsdale, AZ", "Reno, NV",
      "Buffalo, NY", "Gilbert, AZ", "Glendale, AZ", "North Las Vegas, NV", "Winston-Salem, NC",
      "Chesapeake, VA", "Norfolk, VA", "Fremont, CA", "Garland, TX", "Irving, TX",
      "Hialeah, FL", "Richmond, VA", "Boise, ID", "Spokane, WA", "Baton Rouge, LA",
      "Tacoma, WA", "San Bernardino, CA", "Modesto, CA", "Fontana, CA", "Des Moines, IA",
      "Moreno Valley, CA", "Santa Clarita, CA", "Fayetteville, NC", "Birmingham, AL", "Oxnard, CA",
      "Rochester, NY", "Port St. Lucie, FL", "Grand Rapids, MI", "Huntsville, AL", "Salt Lake City, UT",
      "Frisco, TX", "Yonkers, NY", "Amarillo, TX", "Glendale, CA", "Huntington Beach, CA",
      "McKinney, TX", "Montgomery, AL", "Augusta, GA", "Aurora, IL", "Akron, OH",
      "Little Rock, AR", "Tempe, AZ", "Columbus, GA", "Overland Park, KS", "Grand Prairie, TX",
      "Tallahassee, FL", "Cape Coral, FL", "Mobile, AL", "Knoxville, TN", "Shreveport, LA",
      "Worcester, MA", "Ontario, CA", "Vancouver, WA", "Sioux Falls, SD", "Chattanooga, TN",
      "Brownsville, TX", "Fort Lauderdale, FL", "Providence, RI", "Newport News, VA", "Rancho Cucamonga, CA",
      "Santa Rosa, CA", "Peoria, AZ", "Oceanside, CA", "Elk Grove, CA", "Salem, OR",
      "Pembroke Pines, FL", "Eugene, OR", "Garden Grove, CA", "Cary, NC", "Fort Collins, CO",
      "Corona, CA", "Springfield, MO", "Jackson, MS", "Alexandria, VA", "Hayward, CA",
      "Clarksville, TN", "Lakewood, CO", "Lancaster, CA", "Salinas, CA", "Palmdale, CA",
      "Hollywood, FL", "Springfield, MA", "Macon, GA", "Sunnyvale, CA", "Pomona, CA",
      "Killeen, TX", "Escondido, CA", "Pasadena, TX", "Naperville, IL", "Bellevue, WA",
      "Joliet, IL", "Murfreesboro, TN", "Midland, TX", "Rockford, IL", "Paterson, NJ",
      "Savannah, GA", "Bridgeport, CT", "Torrance, CA", "McAllen, TX", "Syracuse, NY",
      "Surprise, AZ", "Denton, TX", "Roseville, CA", "Thornton, CO", "Miramar, FL",
      "Pasadena, CA", "Mesquite, TX", "Olathe, KS", "Dayton, OH", "Carrollton, TX",
      "Waco, TX", "Orange, CA", "Fullerton, CA", "Charleston, SC", "West Valley City, UT",
      "Visalia, CA", "Hampton, VA", "Gainesville, FL", "Warren, MI", "Coral Springs, FL",
      "Round Rock, TX", "Sterling Heights, MI", "Kent, WA", "Columbia, SC", "Santa Clara, CA",
      "New Haven, CT", "Stamford, CT", "Concord, CA", "Elizabeth, NJ", "Athens, GA",
      "Thousand Oaks, CA", "Lafayette, LA", "Simi Valley, CA", "Topeka, KS", "Norman, OK",
      "Fargo, ND", "Wilmington, NC", "Abilene, TX", "Odessa, TX", "Pearland, TX",
      "Victorville, CA", "Hartford, CT", "Vallejo, CA", "Allentown, PA", "Berkeley, CA",
      "Richardson, TX", "Arvada, CO", "Ann Arbor, MI", "Rochester, MN", "Cambridge, MA",
      "Sugar Land, TX", "Lansing, MI", "Evansville, IN", "College Station, TX", "Fairfield, CA",
      "Clearwater, FL", "Beaumont, TX", "Independence, MO", "Provo, UT", "West Jordan, UT",
      "Murrieta, CA", "Palm Bay, FL", "El Monte, CA", "Carlsbad, CA", "North Charleston, SC",
      "Temecula, CA", "Clovis, CA", "Meridian, ID", "Westminster, CO", "League City, TX",
      "Pueblo, CO", "Gresham, OR", "High Point, NC", "Billings, MT", "Waterbury, CT",
      "Antioch, CA", "Everett, WA", "Downey, CA", "Green Bay, WI", "Centennial, CO",
      "Broken Arrow, OK", "Richmond, CA", "Inglewood, CA", "Burbank, CA", "Sandy Springs, GA",
      "Pompano Beach, FL", "Costa Mesa, CA", "Daly City, CA", "Manchester, NH", "Miami Gardens, FL",
      "Norwalk, CA", "West Palm Beach, FL", "Wichita Falls, TX", "Greenville, NC", "Lakeland, FL",
      "San Mateo, CA", "Rialto, CA", "Boulder, CO", "Edison, NJ", "Davenport, IA",
      "Hillsboro, OR", "Woodbridge, NJ", "Kenosha, WI", "South Bend, IN", "El Cajon, CA",
      "Renton, WA", "Tyler, TX", "Jurupa Valley, CA", "Allen, TX", "Sparks, NV",
      "Santa Maria, CA", "Lee's Summit, MO", "New Bedford, MA", "Concord, NC", "Davie, FL",
      "Goodyear, AZ",
      "Buckeye, AZ",
      "Avondale, AZ",
      "Flagstaff, AZ",
      "Yuma, AZ",
      "Lake Havasu City, AZ",
      "Casa Grande, AZ",
      "Maricopa, AZ",
      "Prescott, AZ",
      "Kingman, AZ",
      "Sierra Vista, AZ",
      "Bullhead City, AZ",
      "San Tan Valley, AZ",
      "Apache Junction, AZ",
      "Marana, AZ",
      "Oro Valley, AZ",
      "Queen Creek, AZ",
      "Prescott Valley, AZ",
      "Payson, AZ",
      "Sahuarita, AZ",
      "Safford, AZ",
      "Nogales, AZ",
      "Arkadelphia, AR",
      "Benton, AR",
      "Cabot, AR",
      "Conway, AR",
      "Hot Springs, AR",
      "Jacksonville, AR",
      "Jonesboro, AR",
      "Maumelle, AR",
      "Paragould, AR",
      "Pine Bluff, AR",
      "Rogers, AR",
      "Russellville, AR",
      "Sherwood, AR",
      "Searcy, AR",
      "Springdale, AR",
      "Texarkana, AR",
      "Van Buren, AR",
      "West Memphis, AR",
      "Bella Vista, AR",
      "Bentonville, AR",
      "Bryant, AR",
      "Fayetteville, AR",
      "Fort Smith, AR",
      "Mountain Home, AR",
      "Prescott, AR",
      "Alameda, CA",
      "Alhambra, CA",
      "Apple Valley, CA",
      "Arcadia, CA",
      "Baldwin Park, CA",
      "Buena Park, CA",
      "Chico, CA",
      "Chino, CA",
      "Chino Hills, CA",
      "Citrus Heights, CA",
      "Compton, CA",
      "Davis, CA",
      "Delano, CA",
      "Diamond Bar, CA",
      "Eastvale, CA",
      "El Centro, CA",
      "Encinitas, CA",
      "Folsom, CA",
      "Fountain Valley, CA",
      "Gilroy, CA",
      "Glendora, CA",
      "Hanford, CA",
      "Hawthorne, CA",
      "Hemet, CA",
      "Hesperia, CA",
      "Indio, CA",
      "La Habra, CA",
      "La Mesa, CA",
      "La Mirada, CA",
      "La Quinta, CA",
      "Lake Elsinore, CA",
      "Lake Forest, CA",
      "Lakewood, CA",
      "Livermore, CA",
      "Lodi, CA",
      "Lompoc, CA",
      "Rancho Palos Verdes, CA",
      "Los Banos, CA",
      "Madera, CA",
      "Manteca, CA",
      "Menifee, CA",
      "Milpitas, CA",
      "Mission Viejo, CA",
      "Monrovia, CA",
      "Montebello, CA",
      "Monterey Park, CA",
      "Mountain View, CA",
      "National City, CA",
      "Newport Beach, CA",
      "Novato, CA",
      "Oakley, CA",
      "Orangevale, CA",
      "Palo Alto, CA",
      "Paramount, CA",
      "Petaluma, CA",
      "Pittsburg, CA",
      "Pleasanton, CA",
      "Rancho Cordova, CA",
      "Redlands, CA",
      "Redondo Beach, CA",
      "Redding, CA",
      "Redwood City, CA",
      "Rocklin, CA",
      "Rowland Heights, CA",
      "San Bruno, CA",
      "San Leandro, CA",
      "San Marcos, CA",
      "San Ramon, CA",
      "Santa Barbara, CA",
      "Santa Cruz, CA",
      "Santa Monica, CA",
      "Santee, CA",
      "Saratoga, CA",
      "South Gate, CA",
      "South San Francisco, CA",
      "Tracy, CA",
      "Turlock, CA",
      "Union City, CA",
      "Vacaville, CA",
      "Walnut Creek, CA",
      "Watsonville, CA",
      "West Covina, CA",
      "Westminster, CA",
      "Whittier, CA",
      "Yorba Linda, CA",
      "Broomfield, CO",
      "Castle Rock, CO",
      "Commerce City, CO",
      "Englewood, CO",
      "Erie, CO",
      "Golden, CO",
      "Grand Junction, CO",
      "Greeley, CO",
      "Highlands Ranch, CO",
      "Littleton, CO",
      "Longmont, CO",
      "Loveland, CO",
      "Northglenn, CO",
      "Parker, CO",
      "Windsor, CO",
      "Danbury, CT",
      "Glastonbury, CT",
      "Greenwich, CT",
      "Hamden, CT",
      "Manchester, CT",
      "Meriden, CT",
      "Milford, CT",
      "New Britain, CT",
      "Norwalk, CT",
      "Norwich, CT",
      "Shelton, CT",
      "Southington, CT",
      "Stratford, CT",
      "Trumbull, CT",
      "West Hartford, CT",
      "Wethersfield, CT",
      "Wilmington, DE",
      "Dover, DE",
      "Newark, DE",
      "Middletown, DE",
      "Middletown, CT",
      "Boca Raton, FL",
      "Bonita Springs, FL",
      "Boynton Beach, FL",
      "Bradenton, FL",
      "Brandon, FL",
      "Clermont, FL",
      "Coral Gables, FL",
      "Delray Beach, FL",
      "Fort Myers, FL",
      "Homestead, FL",
      "Kissimmee, FL",
      "Largo, FL",
      "Melbourne, FL",
      "Miami Beach, FL",
      "Ocala, FL",
      "Palm Coast, FL",
      "Palm Beach Gardens, FL",
      "Pensacola, FL",
      "Plantation, FL",
      "Punta Gorda, FL",
      "Sarasota, FL",
      "Spring Hill, FL",
      "Tamarac, FL",
      "Titusville, FL",
      "Wellington, FL",
      "Winter Garden, FL",
      "Winter Haven, FL",
      "Winter Park, FL",
      "Albany, GA",
      "Brookhaven, GA",
      "Johns Creek, GA",
      "Marietta, GA",
      "Roswell, GA",
      "Smyrna, GA",
      "Valdosta, GA",
      "Warner Robins, GA",
      "Kahului, HI",
      "Hilo, HI",
      "Kailua, HI",
      "Kaneohe, HI",
      "Kapolei, HI",
      "Pearl City, HI",
      "Des Plaines, IL",
      "Elgin, IL",
      "Evanston, IL",
      "Oak Lawn, IL",
      "Oak Park, IL",
      "Palatine, IL",
      "Schaumburg, IL",
      "Skokie, IL",
      "Springfield, IL",
      "Waukegan, IL",
      "Bolingbrook, IL",
      "Buffalo Grove, IL",
      "Cicero, IL",
      "Downers Grove, IL",
      "Lombard, IL",
      "Mount Prospect, IL",
      "Orland Park, IL",
      "Tinley Park, IL",
      "West Chicago, IL",
      "Bloomington, IN",
      "Carmel, IN",
      "Fishers, IN",
      "Gary, IN",
      "Greenwood, IN",
      "Hammond, IN",
      "Lafayette, IN",
      "Muncie, IN",
      "Noblesville, IN",
      "Terre Haute, IN",
      "Anderson, IN",
      "Columbus, IN",
      "Jeffersonville, IN",
      "Kokomo, IN",
      "Mishawaka, IN",
      "Richmond, IN",
      "Fort Dodge, IA",
      "Cedar Falls, IA",
      "Cedar Rapids, IA",
      "Council Bluffs, IA",
      "Dubuque, IA",
      "Iowa City, IA",
      "Sioux City, IA",
      "Waterloo, IA",
      "Ankeny, IA",
      "Bettendorf, IA",
      "Marion, IA",
      "Urbandale, IA",
      "Lawrence, KS",
      "Lenexa, KS",
      "Manhattan, KS",
      "Salina, KS",
      "Shawnee, KS",
      "Bowling Green, KY",
      "Covington, KY",
      "Florence, KY",
      "Georgetown, KY",
      "Owensboro, KY",
      "Richmond, KY",
      "Bossier City, LA",
      "Kenner, LA",
      "Lake Charles, LA",
      "Monroe, LA",
      "Slidell, LA",
      "Alexandria, LA",
      "Beverly, MA",
      "Brookline, MA",
      "Fall River, MA",
      "Framingham, MA",
      "Haverhill, MA",
      "Lawrence, MA",
      "Lowell, MA",
      "Lynn, MA",
      "Malden, MA",
      "Medford, MA",
      "Newton, MA",
      "Quincy, MA",
      "Somerville, MA",
      "Waltham, MA",
      "Wellesley, MA",
      "Weymouth, MA",
      "Battle Creek, MI",
      "Dearborn, MI",
      "Dearborn Heights, MI",
      "Farmington Hills, MI",
      "Flint, MI",
      "Kalamazoo, MI",
      "Livonia, MI",
      "Novi, MI",
      "Pontiac, MI",
      "Rochester Hills, MI",
      "Royal Oak, MI",
      "Saginaw, MI",
      "Southfield, MI",
      "Taylor, MI",
      "Troy, MI",
      "Wayne, MI",
      "Bloomington, MN",
      "Brooklyn Park, MN",
      "Burnsville, MN",
      "Duluth, MN",
      "Eagan, MN",
      "Eden Prairie, MN",
      "Maple Grove, MN",
      "Minnetonka, MN",
      "Plymouth, MN",
      "St. Cloud, MN",
      "Woodbury, MN",
      "Columbia, MO",
      "Florissant, MO",
      "Joplin, MO",
      "O'Fallon, MO",
      "St. Joseph, MO",
      "St. Peters, MO",
      "Blue Springs, MO",
      "Cape Girardeau, MO",
      "Biloxi, MS",
      "Gulfport, MS",
      "Hattiesburg, MS",
      "Southaven, MS",
      "Tupelo, MS",
      "Bozeman, MT",
      "Great Falls, MT",
      "Helena, MT",
      "Missoula, MT",
      "Grand Island, NE",
      "Kearney, NE",
      "Bellevue, NE",
      "Papillion, NE",
      "Carson City, NV",
      "Enterprise, NV",
      "Mesquite, NV",
      "Paradise, NV",
      "Nashua, NH",
      "Concord, NH",
      "Derry, NH",
      "Dover, NH",
      "Rochester, NH",
      "Atlantic City, NJ",
      "Bayonne, NJ",
      "Clifton, NJ",
      "Hackensack, NJ",
      "Hoboken, NJ",
      "Lakewood, NJ",
      "New Brunswick, NJ",
      "Perth Amboy, NJ",
      "Princeton, NJ",
      "Trenton, NJ",
      "Union City, NJ",
      "Wayne, NJ",
      "West Orange, NJ",
      "Las Cruces, NM",
      "Rio Rancho, NM",
      "Santa Fe, NM",
      "Roswell, NM",
      "Albany, NY",
      "Binghamton, NY",
      "Ithaca, NY",
      "Mount Vernon, NY",
      "New Rochelle, NY",
      "Niagara Falls, NY",
      "Poughkeepsie, NY",
      "Schenectady, NY",
      "Utica, NY",
      "White Plains, NY",
      "Asheville, NC",
      "Burlington, NC",
      "Chapel Hill, NC",
      "Gastonia, NC",
      "Jacksonville, NC",
      "Rocky Mount, NC",
      "Wilson, NC",
      "Bismarck, ND",
      "Grand Forks, ND",
      "Canton, OH",
      "Cleveland Heights, OH",
      "Dublin, OH",
      "Fairfield, OH",
      "Hamilton, OH",
      "Lakewood, OH",
      "Mansfield, OH",
      "Mason, OH",
      "Mentor, OH",
      "Parma, OH",
      "Strongsville, OH",
      "Toledo, OH",
      "Youngstown, OH",
      "Edmond, OK",
      "Enid, OK",
      "Lawton, OK",
      "Moore, OK"],
    UK: [
      "London", "Birmingham", "Manchester", "Glasgow", "Liverpool", "Bristol", "Edinburgh", "Sheffield", "Leeds", "Leicester", "Coventry", "Bradford", "Cardiff", "Belfast", "Nottingham", "Newcastle upon Tyne", "Hull", "Southampton", "Reading", "Derby", "Plymouth", "Stoke-on-Trent", "Wolverhampton", "Swansea", "Milton Keynes", "Aberdeen", "Northampton", "Luton", "Portsmouth", "Norwich", "Abingdon", "Accrington", "Aldridge", "Alfreton", "Alnwick", "Arundel", "Atherstone", "Axminster", "Bacup", "Baldock", "Banbury", "Banstead", "Barnard Castle", "Barrow-in-Furness", "Barton-upon-Humber", "Beccles", "Belper", "Berwick-upon-Tweed", "Bideford", "Biggleswade", "Bingley", "Bishop's Waltham", "Blackburn", "Blandford Forum", "Bolsover", "Bodmin", "Bognor Regis", "Boston", "Bourne", "Brandon", "Brechin", "Brentford", "Bridport", "Brigg", "Brixham", "Broadstairs", "Bromley", "Buckingham", "Burnham-on-Crouch", "Burnham-on-Sea", "Burslem", "Burton Latimer", "Bury St Edmunds", "Callington", "Camborne", "Canvey Island", "Carlton", "Carnforth", "Caterham", "Chard", "Chipping Norton", "Chipping Sodbury", "Chorleywood", "Cirencester", "Clay Cross", "Cleckheaton", "Clevedon", "Coalville", "Cockermouth", "Codsall", "Corby", "Coseley", "Crowthorne", "Crowborough", "Darwen", "Daventry", "Dawlish", "Deeside", "Dereham", "Devizes", "Diss", "Droitwich Spa", "Dronfield", "Dukinfield", "Dunstable", "Earl Shilton", "East Retford", "Ebbw Vale", "Eccles", "Egham", "Ellesmere", "Emsworth", "Enfield", "Epping", "Erith", "Evesham", "Exmouth", "Faringdon", "Farnborough", "Farnham", "Ferndown", "Filey", "Finningley", "Frodsham", "Gainsborough", "Garstang", "Glastonbury", "Glenfield", "Godalming", "Goodmayes", "Gosport", "Grantham", "Gravesend", "Great Harwood", "Great Malvern", "Great Missenden", "Grimsby", "Guiseley", "Hadleigh", "Halstead", "Haslemere", "Hatherleigh", "Haverhill", "Hednesford", "Hessle", "Heywood", "Higham Ferrers", "Hinckley", "Hindley", "Holmfirth", "Horncastle", "Hornchurch", "Horwich", "Hucknall", "Hungerford", "Huntingdon", "Ilkeston", "Immingham", "Ingleby Barwick", "Iver", "Jarrow", "Keswick", "Keynsham", "Kingsbridge", "Kingswood", "Kirkby", "Knutsford", "Lakenheath", "Lancaster", "Langley", "Leek", "Leighton-Linslade", "Letchworth Garden City", "Litherland", "Littleborough", "Louth", "Lymington", "Lymm", "Lyme Regis", "Mablethorpe", "Maghull", "Maldon", "Malvern", "March", "Market Drayton", "Market Weighton", "Marlborough", "Matlock", "Melksham", "Mexborough", "Middleton", "Milford Haven", "Moreton-in-Marsh", "Musselburgh", "Nailsea", "Nantwich", "New Mills", "New Milton", "Newport Pagnell", "North Walsham", "Northallerton", "Northfleet", "Northolt", "Northwood", "Oakengates", "Okehampton", "Ormskirk", "Otley", "Painswick", "Petersfield", "Pocklington", "Polegate", "Portishead", "Prescot", "Radcliffe", "Ramsgate", "Raunds", "Rawmarsh", "Redcar", "Ringwood", "Ripley", "Rochford", "Romsey", "Rossendale", "Rotherham", "Rowley Regis", "Rugeley", "Saffron Walden", "Sandown", "Sandy", "Seaham", "Sedbergh", "Shanklin", "Shoreham-by-Sea", "Shrewsbury", "Shildon", "Shipley", "Shoreham", "Sidmouth", "Skelmersdale", "Soham", "Southam", "Southborough", "South Molton", "South Normanton", "Southwick", "St Neots", "Stamford", "Staveley", "Steyning", "Stourport-on-Severn", "Street", "Stretford", "Sudbury", "Sutton", "Swaffham", "Swanley", "Swanscombe", "Tadcaster", "Tadley", "Tarporley", "Tavistock", "Thame", "Thornbury", "Thurrock", "Tidworth", "Tiverton", "Todmorden", "Towcester", "Trimdon", "Tring", "Trowbridge", "Uckfield", "Ulverston", "Uttoxeter", "Verwood", "Wadebridge", "Wallingford", "Waltham Abbey", "Ware", "Warminster", "Wednesfield", "Wells", "Weston-super-Mare", "Wetherby", "Whitchurch", "Whitby", "Wickford", "Wigton", "Witney", "Woodley", "Woolwich", "Wymondham", "Yateley", "Yeadon", "Yarmouth", "Yate", "Zouch", "Abergele", "Aberystwyth", "Abergavenny", "Blackwood", "Caerphilly", "Chepstow", "Haverfordwest", "Llanfairfechan", "Llanrwst", "Machynlleth", "Merthyr", "Mold", "Penycae", "Porthmadog", "Shotton", "Tredegar", "Welshpool", "Bearsden", "Bishopbriggs", "Bo'ness", "Burntisland", "Callander", "Campbeltown", "Carluke", "Clackmannan", "Crieff", "Cupar", "Dalkeith", "Dingwall", "Dunoon", "Duntocher", "Earlston", "Forres", "Fraserburgh", "Giffnock", "Haddington", "Inverurie", "Jedburgh", "Kelso", "Lochgelly", "Maybole", "Melrose", "Monifieth", "Newton Stewart", "North Berwick", "Peebles", "Rothes", "Selkirk", "Stepps", "Thurso", "Tranent", "Uddingston", "Wick", "Ballyclare", "Ballynahinch", "Bessbrook", "Broughshane", "Clogher", "Crumlin", "Dromore", "Holywood", "Kilkeel", "Killyleagh", "Lurgan", "Moy", "Newcastle Northern Ireland", "Portaferry", "Randalstown", "Roscommon", "Warrenpoint", "Barmouth", "Beaumaris", "Beddgelert", "Betws-y-Coed", "Brecon", "Cardigan", "Ceredigion", "Fishguard", "Llandeilo", "Llandovery", "Llanidloes", "Llanwrst", "Newport Wales", "Pembroke", "Pembroke Dock", "St Asaph", "Usk", "Whitland", "Aberfeldy", "Auchterarder", "Auchinleck", "Aviemore", "Banff Scotland", "Blairgowrie", "Bridge of Allan", "Dunbar", "Eyemouth", "Huntly", "Inveraray", "Inverkeithing", "Kinross", "Lanark", "Largs", "Lenzie", "Lesmahagow", "Loanhead", "Lochgilphead", "Macduff", "Moffat", "Montrose", "Newport-on-Tay", "Newton Mearns", "Port Glasgow", "Prestwick", "Rutherglen Scotland", "Shotts", "South Queensferry", "Tain", "Ullapool", "Westhill", "Whitburn Scotland", "Wishaw", "Ballycastle", "Ballygawley", "Ballymoney", "Castlewellan", "Comber", "Cushendall", "Donaghadee", "Dungannon", "Garvagh", "Greenisland", "Larne", "Lisnaskea", "Markethill", "Moira", "Rostrevor", "Saintfield", "Waringstown", "Acton", "Balham", "Battersea", "Bethnal Green", "Brixton", "Camden", "Chiswick", "Clapham", "Dalston", "Ealing", "Edgware", "Finchley", "Fulham", "Greenwich", "Hackney", "Hammersmith", "Hampstead", "Harrow", "Hendon", "Highgate", "Hounslow", "Islington", "Kensington", "Kingston", "Lewisham", "Leyton", "Maida Vale", "Marylebone", "Merton", "Mill Hill", "Neasden", "Newham", "Norwood", "Notting Hill", "Paddington", "Putney", "Richmond upon Thames", "Rotherhithe", "Shepherds Bush", "Shoreditch", "Southgate", "Stamford Hill", "Streatham", "Tooting", "Tottenham", "Twickenham", "Walthamstow", "Wanstead", "Wandsworth", "Wembley", "West Ham", "West Hampstead", "Wimbledon", "Winchmore Hill", "Woodford", "Barking", "Bexley", "Carshalton", "Chingford", "Croydon", "Dartford", "Feltham", "Harrow Weald", "Hayes", "Hillingdon", "Ilford", "Orpington", "Purley", "Romford", "Sidcup", "Upminster", "Uxbridge", "Wallington", "Warlingham", "Welling", "Westerham", "Chatham", "Maidstone", "Margate", "Medway", "Rochester", "Sevenoaks", "Sittingbourne", "Tonbridge", "Tunbridge Wells", "Ashford Kent", "Canterbury", "Dover", "Folkestone", "Herne Bay", "Whitstable", "Bexhill", "Eastbourne", "Hastings", "Lewes", "Peacehaven", "Seaford", "Worthing", "Chichester", "Crawley", "East Grinstead", "Haywards Heath", "Horsham", "Littlehampton", "Redhill", "Reigate", "Fareham", "Havant", "Portchester", "Winchester", "Andover", "Basingstoke", "Eastleigh", "Fleet", "Guildford", "Leatherhead", "Woking", "Wokingham", "Bracknell", "Maidenhead", "Newbury", "Slough", "Windsor", "Amersham", "Aylesbury", "Beaconsfield", "High Wycombe", "Bicester", "Didcot", "Oxford", "Cheltenham", "Gloucester", "Stroud", "Tewkesbury", "Bath", "Bridgwater", "Frome", "Taunton", "Yeovil", "Exeter", "Torquay", "Truro", "Falmouth", "Newquay", "Penzance", "St Austell", "Barnstaple", "Paignton", "Salisbury", "Swindon", "Chippenham", "Worcester", "Hereford", "Kidderminster", "Redditch", "Dudley", "Solihull", "Walsall", "West Bromwich", "Tamworth", "Lichfield", "Stafford", "Stoke", "Crewe", "Macclesfield", "Wilmslow", "Stockport", "Altrincham", "Bolton", "Bury", "Oldham", "Rochdale", "Salford", "Wigan", "Warrington", "Chester", "Chesterfield", "Mansfield", "Newark", "Lincoln", "Skegness", "Loughborough", "Kettering", "Peterborough", "Cambridge", "Ely", "Ipswich", "Colchester", "Chelmsford", "Basildon", "Southend", "Lowestoft", "Great Yarmouth", "King's Lynn", "Bedford", "Stevenage", "St Albans", "Watford", "Hemel Hempstead", "Welwyn Garden City", "Hertford", "Bishop's Stortford", "Rugby", "Nuneaton", "Warwick", "Leamington Spa", "Stratford-upon-Avon", "Bromsgrove", "Telford", "Oswestry", "Wrexham", "Bangor Wales", "Caernarfon", "Colwyn Bay", "Conwy", "Rhyl", "Llandudno", "Holyhead", "Newtown Wales", "Merthyr Tydfil", "Pontypridd", "Barry", "Bridgend", "Neath", "Carmarthen", "Llanelli", "Aberdare", "Dundee", "Dunfermline", "Perth Scotland", "Stirling", "Falkirk", "Livingston", "Cumbernauld", "Kirkcaldy", "Glenrothes", "Ayr", "Kilmarnock", "Irvine", "Paisley", "Hamilton", "Motherwell", "East Kilbride", "Coatbridge", "Airdrie", "Dumfries", "Ayrshire", "Inverness", "Elgin", "Nairn", "Peterhead", "Arbroath", "St Andrews", "Perth", "Oban", "Fort William", "Lerwick", "Kirkwall", "Lisburn", "Newtownabbey", "Bangor NI", "Carrickfergus", "Newry"],
    AU: [
      "Sydney, NSW", "Melbourne, VIC", "Brisbane, QLD", "Perth, WA", "Adelaide, SA", "Gold Coast, QLD", "Newcastle, NSW", "Canberra, ACT", "Sunshine Coast, QLD", "Wollongong, NSW", "Geelong, VIC", "Hobart, TAS", "Townsville, QLD", "Cairns, QLD", "Toowoomba, QLD", "Darwin, NT", "Ballarat, VIC", "Bendigo, VIC", "Albury, NSW", "Launceston, TAS", "Aitkenvale", "Ararat", "Armidale", "Ascot Vale", "Bairnsdale", "Balgowlah", "Balmain", "Bannockburn", "Barcaldine", "Beaconsfield", "Beaudesert", "Beaufort", "Beechworth", "Bellingen", "Bendigo East", "Berwick", "Beveridge", "Blackburn", "Blackheath", "Blacktown", "Bongaree", "Bordertown", "Bowral", "Braybrook", "Brunswick East", "Bundaberg North", "Burwood East", "Byron Bay", "Cambridge Park", "Campbelltown NSW", "Canley Vale", "Capalaba", "Carlingford", "Carnegie", "Carrum Downs", "Castle Hill", "Castlemaine", "Cessnock", "Chadstone", "Cheltenham", "Chinchilla", "Clayton", "Cobar", "Coffs Harbour", "Cooma", "Cranbourne East", "Cranbourne North", "Cranbourne West", "Croydon", "Currumbin", "Dapto", "Darlinghurst", "Dee Why", "Deer Park", "Derrimut", "Doncaster East", "Donnybrook", "Drummoyne", "Dubbo", "Dural", "Eagle Farm", "Eastwood", "Echuca", "Edithvale", "Eltham", "Emerald QLD", "Engadine", "Erina", "Fairfield NSW", "Fairfield VIC", "Ferntree Gully", "Five Dock", "Forster", "Frankston North", "Glen Iris", "Glenorchy", "Glen Waverley", "Glenelg", "Gosford", "Goulburn", "Grafton", "Granville", "Greenacre", "Greensborough", "Greystanes", "Guildford NSW", "Hampton Park", "Hawthorn East", "Hornsby", "Hurstville", "Ingleburn", "Innisfail", "Jindabyne", "Joondalup", "Kallangur", "Kangaroo Flat", "Katoomba", "Kellyville", "Kempsey", "Kilsyth", "Kingscote", "Kingston SA", "Kingston QLD", "Kingscliff", "Knoxfield", "Kurri Kurri", "Lara", "Lawnton", "Leeton", "Lennox Head", "Leopold", "Lidcombe", "Lilydale", "Lismore", "Lockyer Valley", "Macksville", "Maleny", "Malvern VIC", "Manly NSW", "Maribyrnong", "Margate TAS", "Marion", "Marsden Park", "Mawson Lakes", "Meadowbank", "Melton South", "Menai", "Mentone", "Merrimac", "Merrylands", "Middle Park VIC", "Mildura South", "Miranda", "Mittagong", "Modbury", "Mona Vale", "Montrose", "Moorebank", "Mornington Peninsula", "Mosman", "Mount Barker SA", "Mount Cotton", "Mount Eliza", "Mount Evelyn", "Mount Isa", "Mount Martha", "Mount Pleasant WA", "Mount Waverley", "Mudgee", "Mulgrave", "Murray Bridge", "Narre Warren South", "Neutral Bay", "New Farm", "New Norfolk", "New Lambton", "Newcastle West", "Newcastle-under-Lyme AU", "Newport VIC", "Noble Park", "North Adelaide", "North Sydney", "Northcote", "North Lakes", "North Parramatta", "North Perth", "North Ryde", "North Shore", "Oakleigh South", "Ocean Shores", "Orange NSW", "Oran Park", "Padstow", "Palm Beach QLD", "Panania", "Parramatta West", "Parkes", "Park Ridge", "Pascoe Vale", "Paynesville", "Point Cook", "Port Fairy", "Port Lincoln", "Port Melbourne", "Port Noarlunga", "Port Pirie", "Portland VIC", "Prospect SA", "Quakers Hill", "Queenstown TAS", "Raby", "Ravenshoe", "Reservoir", "Richmond NSW", "Richmond TAS", "Ringwood East", "Riverview", "Rosebud", "Roseville", "Rowville", "Roxburgh Park", "Runcorn QLD", "Ryde NSW", "Sandy Bay", "Sarina", "Scarborough QLD", "Seaford VIC", "Seaton", "Semaphore", "Seven Hills", "Shoalhaven", "Singleton NSW", "Smithfield NSW", "Somerville", "South Morang", "Springfield QLD", "St Agnes SA", "St Albans VIC", "St Clair NSW", "St Ives NSW", "St Leonards NSW", "St Marys NSW", "Stanhope Gardens", "Stanwell Park", "Sunshine West", "Surfers Paradise", "Sutherland", "Swan View", "Sydenham VIC", "Taren Point", "Taylors Lakes", "Templestowe", "The Entrance", "Thirroul", "Thornbury VIC", "Thuringowa", "Toongabbie", "Truganina", "Tuggerah", "Tweed Heads South", "Wahroonga", "Wagga North", "Waurn Ponds", "Werribee South", "West Footscray", "West Lakes", "West Pennant Hills", "West Ryde", "West Torrens", "Wheelers Hill", "Windsor NSW", "Windsor QLD", "Wollert", "Woolloongabba", "Wooloowin", "Woolgoolga", "Woy Woy", "Yarraville", "Yass", "Yea", "Yennora", "Young NSW", "Yowie Bay", "Yungaburra", "Zetland", "Bathurst", "Blaxland", "Budgewoi", "Bulli", "Caringbah", "Condobolin", "Cootamundra", "Culburra", "Denman", "Forbes", "Glen Innes", "Gunnedah", "Inverell", "Maitland", "Moree", "Muswellbrook", "Narrabri", "Narrandera", "Quirindi", "Scone", "Tenterfield", "Tumbarumba", "Tumut", "Walcha", "Warrawong", "Wauchope", "Wingham", "Young", "Bacchus Marsh", "Clunes", "Colac", "Creswick", "Drouin", "Euroa", "Hamilton VIC", "Healesville", "Horsham", "Kerang", "Kyabram", "Leongatha", "Maffra", "Maryborough VIC", "Moe", "Mooroopna", "Morwell", "Myrtleford", "Orbost", "Portland", "Rutherglen", "Sale", "Seymour", "Stawell", "Terang", "Warragul", "Warrnambool", "Wonthaggi", "Yarram", "Busselton", "Dunsborough", "Esperance", "Exmouth", "Geraldton", "Kalgoorlie-Boulder", "Karratha", "Kwinana", "Mandurah", "Margaret River", "Port Hedland", "Rockingham", "Albany WA", "Broome", "Bunbury", "Collie", "Denmark WA", "Fremantle", "Katanning", "Manjimup", "Midland WA", "Northam", "South Hedland", "Toodyay", "Waroona", "Whyalla", "Gawler", "Goolwa", "Kadina", "Kapunda", "Keith", "Loxton", "Naracoorte", "Peterborough SA", "Port Augusta", "Renmark", "Strathalbyn", "Tanunda", "Victor Harbor", "Wallaroo", "Burnie", "Devonport", "George Town TAS", "Huonville", "Kingston TAS", "Launceston suburbs", "Sorell", "Ulverstone", "Wynyard", "Alice Springs", "Darwin suburbs", "Katherine", "Palmerston", "Tennant Creek", "Canberra suburbs", "Belconnen", "Gungahlin", "Tuggeranong", "Woden", "Weston Creek", "Queanbeyan", "Braidwood", "Moruya", "Nowra", "Ulladulla", "Bega", "Batemans Bay", "Wyong", "Central Coast", "Taree", "Port Macquarie", "Ballina", "Tweed Heads", "Mackay", "Gladstone", "Rockhampton", "Bundaberg", "Hervey Bay", "Maryborough QLD", "Gympie", "Nambour", "Caloundra", "Caboolture", "Redcliffe", "Ipswich", "Toowoomba", "Warwick QLD", "Roma", "Charters Towers", "Townsville", "Ayr QLD", "Ingham", "Cairns", "Mareeba", "Port Douglas", "Mossman", "Weipa", "Thursday Island", "Adelaide Plains", "Barossa", "Clare Valley", "Copper Coast", "Fleurieu Peninsula", "Gawler East", "Mount Barker East", "Murray Bridge East", "Port Elliot", "Victor Harbor East", "Wagga Wagga East", "Albury North", "Albury East", "Bathurst East", "Dubbo East", "Goulburn East", "Orange East", "Tamworth East", "Taree North", "Armidale East", "Coffs Harbour North", "Grafton East", "Lismore East", "Maitland East", "Newcastle East", "Wollongong East", "Ballarat East", "Geelong West", "Geelong North", "Melbourne East", "Melbourne West", "Melbourne North", "Melbourne South", "Dandenong North", "Frankston East", "Mildura East", "Shepparton East", "Warrnambool East", "Perth East", "Perth North", "Perth South", "Rockingham East", "Mandurah East", "Bunbury East", "Geraldton East", "Albany East", "Brisbane East", "Brisbane North", "Brisbane South", "Brisbane West", "Gold Coast North", "Gold Coast South", "Sunshine Coast North", "Sunshine Coast South", "Townsville North", "Townsville South", "Cairns North", "Cairns South", "Hobart North", "Hobart South", "Launceston East", "Darwin North", "Darwin South", "Canberra North", "Canberra South", "Queanbeyan East", "Abbotsford", "Albert Park", "Alexandria", "Allambie Heights", "Annandale", "Artarmon", "Auburn NSW", "Baulkham Hills", "Bella Vista", "Bondi", "Bondi Junction", "Botany", "Brookvale", "Burwood NSW", "Cammeray", "Campsie", "Chatswood", "Chippendale", "Cronulla", "Eastgardens", "Eastlakes", "Earlwood", "Frenchs Forest", "Gladesville", "Glebe", "Kensington NSW", "Kingsgrove", "Lane Cove", "Mascot", "Miranda NSW", "Mosman NSW", "Newtown NSW", "Parramatta NSW", "Rosebery", "Surry Hills", "Sydney Olympic Park", "Wetherill Park", "Willoughby", "Wollstonecraft", "Balcatta", "Baldivis", "Bayswater WA", "Bibra Lake", "Cannington", "Cockburn Central", "Como WA", "Cottesloe", "Dianella", "East Victoria Park", "Ellenbrook", "Forrestfield", "Gosnells", "Halls Head", "Hammond Park", "Innaloo", "Kelmscott", "Kewdale", "Leederville", "Malaga", "Morley", "Mount Lawley", "O'Connor", "Osborne Park", "Rivervale", "Scarborough WA", "South Perth", "Stirling WA", "Subiaco", "Victoria Park", "Wangara", "Warnbro", "West Leederville", "Willetton", "Winthrop", "Yokine", "Ascot QLD", "Alderley", "Auchenflower", "Balmoral QLD", "Bardon", "Boondall", "Bowen Hills", "Brisbane City", "Carindale", "Carina", "Carina Heights", "Clayfield", "Coorparoo", "East Brisbane", "Everton Park", "Gaythorne", "Grange QLD", "Hamilton QLD", "Hendra", "Herston", "Indooroopilly", "Kangaroo Point", "Kelvin Grove", "Morningside", "Newmarket", "Nundah", "Paddington QLD", "Red Hill QLD", "Seven Hills QLD", "Stafford", "Taringa", "Teneriffe", "The Gap", "Wynnum", "Albert Park VIC", "Alphington", "Armadale VIC", "Ashburton", "Balwyn", "Bentleigh", "Blackburn VIC", "Box Hill", "Brighton VIC", "Camberwell", "Canterbury VIC", "Carlton", "Caulfield", "Clifton Hill", "Collingwood", "Cremorne", "Doncaster", "Elsternwick", "Essendon", "Fitzroy", "Fitzroy North", "Glen Huntly", "Hawthorn", "Ivanhoe", "Kew", "Malvern", "Melbourne CBD", "Moonee Ponds", "North Melbourne", "Parkdale", "Parkville", "Prahran", "Preston", "Richmond VIC", "South Melbourne", "South Yarra", "Spotswood", "St Kilda", "Sunshine", "Thornbury", "Toorak", "Williamstown VIC", "Windsor VIC", "Adelaide CBD", "Aldinga", "Athelstone", "Blackwood SA", "Burnside", "Campbelltown SA", "Christie Downs", "Edwardstown", "Findon", "Flinders Park", "Golden Grove", "Greenacres", "Holden Hill", "Ingle Farm", "Kilburn SA", "Magill", "Morphett Vale", "Norwood", "Parafield Gardens", "Payneham", "Seaford SA", "Somerton Park", "Stirling SA", "Unley", "West Beach", "Woodville", "Hobart CBD", "Battery Point", "Bellerive", "Blackmans Bay", "Claremont", "Howrah", "Lenah Valley", "Moonah", "New Town", "Rosny", "Sandy Bay TAS", "South Hobart", "Taroona", "West Hobart", "Belconnen ACT", "Braddon ACT"],
    CA: [
      "Toronto, ON", "Montreal, QC", "Vancouver, BC", "Calgary, AB", "Edmonton, AB",
      "Ottawa, ON", "Winnipeg, MB", "Quebec City, QC", "Hamilton, ON", "Kitchener, ON",
      "London, ON", "Victoria, BC", "Halifax, NS", "Oshawa, ON", "Windsor, ON",
      "Saskatoon, SK", "Regina, SK", "St. John's, NL", "Kelowna, BC", "Barrie, ON"
    ]
  };

  const AGGREGATOR_DOMAINS = [
    "yelp.com", "yellowpages.com", "healthgrades.com", "zocdoc.com",
    "mapquest.com", "facebook.com", "instagram.com", "twitter.com",
    "linkedin.com", "bbb.org", "solvhealth.com", "webmd.com", "tripadvisor.com"
  ];

  const STORAGE_KEY_IDX = "__gmaps_omni_idx__";
  const STORAGE_KEY_KW = "__gmaps_omni_kw__";
  const STORAGE_KEY_CTRY = "__gmaps_omni_country__";
  const STORAGE_KEY_WH = "__gmaps_omni_webhook__";
  const STORAGE_KEY_MAX_CITIES = "__gmaps_omni_max_cities__";
  const STORAGE_KEY_RANGE_START = "__gmaps_omni_range_start__";
  const STORAGE_KEY_RANGE_END = "__gmaps_omni_range_end__";
  const STORAGE_KEY_CATEGORY_FILTER = "__gmaps_omni_category_filter__";
  const STORAGE_KEY_PROGRESS = "__gmaps_omni_job_progress__";
  const STORAGE_KEY_LEGACY_DATA = "__gmaps_omni_leads__";
  const DB_NAME = "OmniHarvesterDB";
  const DB_VERSION = 1;
  const SETTLE_DELAY_SEC = 5;
  const MAX_CITY_RETRIES = 3;

  let savedIdx = 0;
  let savedKeywords = [];
  let savedCountry = "US";
  let savedWebhook = "";
  let savedMaxCities = 100;
  let savedRangeStart = 1;
  let savedRangeEnd = 100;
  let savedCategoryFilter = "";
  let savedProgress = { completed: [], failed: {} };
  let recoveredRecords = [];

  function readSettings() {
    try {
      savedIdx = parseInt(localStorage.getItem(STORAGE_KEY_IDX) || "0", 10);
      if (isNaN(savedIdx) || savedIdx < 0) savedIdx = 0;
      const rawKw = localStorage.getItem(STORAGE_KEY_KW) || "";
      savedKeywords = rawKw.split(/\r?\n/).map(s => s.trim()).filter(Boolean);
      savedCountry = localStorage.getItem(STORAGE_KEY_CTRY) || "US";
      savedWebhook = localStorage.getItem(STORAGE_KEY_WH) || "";
      savedMaxCities = parseInt(localStorage.getItem(STORAGE_KEY_MAX_CITIES) || "700", 10);
      if (isNaN(savedMaxCities) || savedMaxCities <= 0) savedMaxCities = 100;
      savedRangeStart = parseInt(localStorage.getItem(STORAGE_KEY_RANGE_START) || "1", 10);
      savedRangeEnd = parseInt(localStorage.getItem(STORAGE_KEY_RANGE_END) || "100", 10);
      savedCategoryFilter = localStorage.getItem(STORAGE_KEY_CATEGORY_FILTER) || "";
      if (isNaN(savedRangeStart) || savedRangeStart < 1) savedRangeStart = 1;
      if (isNaN(savedRangeEnd) || savedRangeEnd < savedRangeStart) savedRangeEnd = Math.max(savedRangeStart, 100);
      const progressRaw = localStorage.getItem(STORAGE_KEY_PROGRESS);
      if (progressRaw) savedProgress = JSON.parse(progressRaw) || savedProgress;
    } catch (e) { console.warn("Settings restore skipped:", e); }
  }

  function openLeadDB() {
    return new Promise((resolve, reject) => {
      const req = indexedDB.open(DB_NAME, DB_VERSION);
      req.onupgradeneeded = () => {
        const db = req.result;
        if (!db.objectStoreNames.contains("leads")) db.createObjectStore("leads", { keyPath: "id" });
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  }

  async function loadLeadRecords() {
    try {
      const db = await openLeadDB();
      const rows = await new Promise((resolve, reject) => {
        const req = db.transaction("leads", "readonly").objectStore("leads").getAll();
        req.onsuccess = () => resolve(req.result || []);
        req.onerror = () => reject(req.error);
      });
      db.close();
      recoveredRecords = rows.map(r => [r.id, r.record]);
      return;
    } catch (e) {
      console.warn("IndexedDB restore failed; trying legacy storage:", e);
    }
    try {
      const raw = localStorage.getItem(STORAGE_KEY_LEGACY_DATA);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) recoveredRecords = parsed;
      }
    } catch (e) { console.warn("Legacy lead restore skipped:", e); }
  }

  readSettings();
  await loadLeadRecords();

  const initialCountry = COUNTRY_PRESETS[savedCountry] ? savedCountry : "US";
  const initialLocations = COUNTRY_PRESETS[initialCountry] || COUNTRY_PRESETS.US;

  window.__gmapsOmni = {
    keywords: savedKeywords,
    keyword: savedKeywords.join("\n"),
    country: initialCountry,
    locations: initialLocations,
    currentIdx: Math.min(savedIdx, initialLocations.length),
    maxCitiesToCollect: Math.min(savedMaxCities, initialLocations.length),
    rangeStart: Math.min(savedRangeStart, initialLocations.length),
    rangeEnd: Math.min(Math.max(savedRangeEnd, savedRangeStart), initialLocations.length),
    categoryFilter: savedCategoryFilter,
    records: new Map(recoveredRecords),
    websiteSet: new Set(recoveredRecords.map(([_, r]) => (r && r.Website ? r.Website : "")).filter(Boolean)),
    completedJobs: new Set(Array.isArray(savedProgress.completed) ? savedProgress.completed : []),
    failedJobs: savedProgress.failed && typeof savedProgress.failed === "object" ? savedProgress.failed : {},
    isRunning: false,
    filterAggregators: true,
    autoBackupBatch: 500,
    lastBackupMilestone: Math.floor(recoveredRecords.length / 500) * 500,
    syncInProgress: false,
    webhookUrl: savedWebhook
  };

  const state = window.__gmapsOmni;

  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const randomSleep = (min, max) => new Promise(r => setTimeout(r, Math.floor(Math.random() * (max - min + 1)) + min));
  const getKeywords = () => (state.keywords.length ? state.keywords : state.keyword.split(/\r?\n/).map(s => s.trim()).filter(Boolean));
  const jobKey = (city, keyword) => `${state.country}::${city}::${keyword.toLowerCase()}`;

  async function persistData() {
    try {
      localStorage.setItem(STORAGE_KEY_IDX, state.currentIdx.toString());
      localStorage.setItem(STORAGE_KEY_KW, state.keywords.join("\n"));
      localStorage.setItem(STORAGE_KEY_CTRY, state.country);
      localStorage.setItem(STORAGE_KEY_WH, state.webhookUrl);
      localStorage.setItem(STORAGE_KEY_MAX_CITIES, state.maxCitiesToCollect.toString());
      localStorage.setItem(STORAGE_KEY_RANGE_START, state.rangeStart.toString());
      localStorage.setItem(STORAGE_KEY_RANGE_END, state.rangeEnd.toString());
      localStorage.setItem(STORAGE_KEY_CATEGORY_FILTER, state.categoryFilter || "");
      localStorage.setItem(STORAGE_KEY_PROGRESS, JSON.stringify({ completed: Array.from(state.completedJobs), failed: state.failedJobs }));

      const db = await openLeadDB();
      const tx = db.transaction("leads", "readwrite");
      const store = tx.objectStore("leads");
      for (const [id, record] of state.records.entries()) store.put({ id, record });
      await new Promise((resolve, reject) => { tx.oncomplete = resolve; tx.onerror = () => reject(tx.error); tx.onabort = () => reject(tx.error); });
      db.close();
    } catch (e) { console.warn("Storage save warning:", e); }
  }

  function markJobComplete(city, keyword) {
    state.completedJobs.add(jobKey(city, keyword));
    delete state.failedJobs[jobKey(city, keyword)];
  }

  function markJobFailed(city, keyword) {
    const key = jobKey(city, keyword);
    state.failedJobs[key] = (state.failedJobs[key] || 0) + 1;
    return state.failedJobs[key];
  }

  function playBeep(freq = 600, duration = 0.3) {
    try {
      const ctx = new (window.AudioContext || window.webkitAudioContext)();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = "sine";
      osc.frequency.setValueAtTime(freq, ctx.currentTime);
      gain.gain.setValueAtTime(0.2, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + duration);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + duration);
    } catch {}
  }

  function playCaptchaAlarm() {
    playBeep(900, 0.2);
    setTimeout(() => playBeep(1200, 0.3), 250);
  }

  function cleanDomain(rawUrl) {
    if (!rawUrl) return "";
    try {
      let target = rawUrl.includes("google.com/url") ? new URL(rawUrl).searchParams.get("q") || rawUrl : rawUrl;
      return new URL(target.startsWith("http") ? target : `https://${target}`).origin;
    } catch {
      return rawUrl;
    }
  }


  function parseAddress(fullText) {
    if (!fullText) return { Street: "", City: "", StateCode: "", Zip: "" };
    const zipMatch = fullText.match(/\b\d{4,5}(-\d{4})?\b/);
    const zip = zipMatch ? zipMatch[0] : "";
    const stateMatch = fullText.match(/\b([A-Z]{2,3})\b\s*\d{4,5}/);
    const stateCode = stateMatch ? stateMatch[1] : "";
    const parts = fullText.split(",").map(p => p.trim());
    return {
      Street: parts[0] || fullText,
      City: parts.length >= 3 ? parts[parts.length - 2].replace(/\b[A-Z]{2,3}\b/, "").trim() : (parts[0] || ""),
      StateCode: stateCode,
      Zip: zip
    };
  }

  function checkCaptcha() {
    const isCaptcha = document.body.innerText.includes("unusual traffic") || 
                      document.body.innerText.includes("solve the challenge below") ||
                      document.querySelector('iframe[src*="recaptcha"]');
    if (isCaptcha) {
      playCaptchaAlarm();
      console.warn("CAPTCHA detected. Complete the verification manually.");
      addActivity("CAPTCHA detected — collection paused", "error");
      return true;
    }
    return false;
  }

  // --- Dynamic DOM selectors for both desktop sidebars and floating panel feeds ---
  function findFeed() {
    const primary = document.querySelector('div[role="feed"]');
    if (primary && primary.scrollHeight > 100) return primary;

    const mainPane = document.querySelector('div[role="main"]');
    if (mainPane) {
      const scrollable = mainPane.querySelector('div.m6QErb.DxyBCb, div.m6QErb[aria-label]');
      if (scrollable && scrollable.scrollHeight > 100) return scrollable;
    }

    const labeled = document.querySelector('div[aria-label*="Results for" i], div[aria-label*="Search results" i]');
    if (labeled && labeled.scrollHeight > 100) return labeled;

    const sampleCard = document.querySelector('.Nv2PK, div[jsaction*="mouseover:pane"]');
    if (sampleCard) {
      let parent = sampleCard.parentElement;
      while (parent && parent !== document.body) {
        if (parent.scrollHeight > parent.clientHeight && parent.clientHeight > 150) {
          return parent;
        }
        parent = parent.parentElement;
      }
    }

    return null;
  }

  async function triggerSearch(queryText) {
    const targetPath = `/maps/search/${encodeURIComponent(queryText).replace(/%20/g, "+")}`;
    
    // Internal state routing
    window.history.pushState({}, "", targetPath);
    window.dispatchEvent(new PopStateEvent("popstate"));

    // DOM search bar trigger
    const input = document.querySelector('input#searchboxinput, input[name="q"], input.searchboxinput');
    if (input) {
      input.focus();
      const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value").set;
      nativeSetter.call(input, queryText);
      input.dispatchEvent(new Event("input", { bubbles: true }));
      input.dispatchEvent(new Event("change", { bubbles: true }));

      await sleep(250);

      const searchBtn = document.querySelector('button#searchbox-searchbutton, button[aria-label="Search"], button.oya7nb');
      if (searchBtn) {
        searchBtn.click();
      } else {
        input.dispatchEvent(new KeyboardEvent("keydown", { key: "Enter", keyCode: 13, code: "Enter", which: 13, bubbles: true }));
      }
    }
  }

  const panel = document.createElement("div");
  panel.id = "gmaps-omni-suite";
  panel.style.cssText = `
    position: fixed;
    top: 15px;
    right: 15px;
    z-index: 9999999;
    background: #0f172a;
    color: #f8fafc;
    padding: 14px;
    border-radius: 12px;
    box-shadow: 0 16px 36px rgba(0,0,0,0.6);
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    font-size: 12px;
    width: 340px;
    max-height: calc(100vh - 30px);
    overflow-y: auto;
    overflow-x: hidden;
    box-sizing: border-box;
    overscroll-behavior: contain;
    scrollbar-width: thin;
    scrollbar-color: #475569 #0b1322;
    border: 1px solid #334155;
  `;

  panel.innerHTML = `
    <style>
      #gmaps-omni-suite::-webkit-scrollbar{width:7px}
      #gmaps-omni-suite::-webkit-scrollbar-track{background:#0b1322;border-radius:10px}
      #gmaps-omni-suite::-webkit-scrollbar-thumb{background:#475569;border-radius:10px}
      #gmaps-omni-suite::-webkit-scrollbar-thumb:hover{background:#64748b}
      #gmaps-omni-suite .oh-card{background:#111c2f;border:1px solid #26364f;border-radius:10px;padding:10px;margin-bottom:9px}
      #gmaps-omni-suite .oh-label{font-size:10px;color:#8ea1bd;font-weight:700;text-transform:uppercase;letter-spacing:.06em;display:block;margin-bottom:4px}
      #gmaps-omni-suite .oh-input,#gmaps-omni-suite select{box-sizing:border-box;width:100%;background:#0b1322;color:#f8fafc;border:1px solid #33445f;border-radius:7px;padding:7px 8px;font-size:11px;outline:none}
      #gmaps-omni-suite .oh-input:focus,#gmaps-omni-suite select:focus{border-color:#38bdf8;box-shadow:0 0 0 2px rgba(56,189,248,.12)}
      #gmaps-omni-suite .oh-row{display:flex;gap:7px;align-items:end}
      #gmaps-omni-suite .oh-btn{border:0;border-radius:8px;padding:8px 9px;color:#fff;font-weight:800;font-size:11px;cursor:pointer}
      #gmaps-omni-suite .oh-btn:hover{filter:brightness(1.08)}
      #gmaps-omni-suite .oh-stat{background:#0b1322;border:1px solid #22324a;border-radius:8px;padding:7px;text-align:center;flex:1}
      #gmaps-omni-suite .oh-stat b{display:block;font-size:15px;color:#f8fafc;line-height:18px}
      #gmaps-omni-suite .oh-stat span{font-size:9px;color:#71839f;text-transform:uppercase;letter-spacing:.05em}
      #gmaps-omni-suite .oh-progress{height:5px;background:#1e293b;border-radius:99px;overflow:hidden;margin-top:7px}
      #gmaps-omni-suite .oh-progress>i{display:block;height:100%;width:0;background:#38bdf8;border-radius:99px}
      #gmaps-omni-suite .oh-muted{font-size:10px;color:#7f91ad}
      #gmaps-omni-suite .oh-activity-log{max-height:170px;overflow:auto;background:#0b1322;border:1px solid #22324a;border-radius:8px;padding:4px}
      #gmaps-omni-suite .oh-log-row{display:flex;gap:6px;align-items:flex-start;padding:6px 5px;border-bottom:1px solid #18263b;font-size:10px;line-height:14px}
      #gmaps-omni-suite .oh-log-row:last-child{border-bottom:0}
      #gmaps-omni-suite .oh-log-time{color:#64748b;min-width:50px;font-variant-numeric:tabular-nums}
      #gmaps-omni-suite .oh-log-icon{width:15px;text-align:center;font-weight:800}
      #gmaps-omni-suite .oh-log-message{color:#cbd5e1;flex:1;word-break:break-word}
      #gmaps-omni-suite .oh-log-success .oh-log-icon{color:#4ade80}
      #gmaps-omni-suite .oh-log-info .oh-log-icon{color:#38bdf8}
      #gmaps-omni-suite .oh-log-warn .oh-log-icon{color:#fbbf24}
      #gmaps-omni-suite .oh-log-error .oh-log-icon{color:#f87171}
      #gmaps-omni-suite .oh-log-empty{padding:18px 8px;text-align:center;color:#64748b;font-size:10px}
    </style>
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;">
      <div>
        <div style="font-weight:850;font-size:15px;color:#f8fafc;letter-spacing:-.02em;">Maps Website Finder <span style="color:#38bdf8;">Pro</span></div>
        <div style="font-size:9px;color:#71839f;margin-top:2px;">GOOGLE MAPS BUSINESS WEBSITE COLLECTOR</div>
      </div>
      <span id="p-status" style="background:#7f1d1d;color:#fecaca;font-size:9px;padding:4px 7px;border-radius:999px;font-weight:800;letter-spacing:.04em;">PAUSED</span>
    </div>

    <div class="oh-card">
      <div class="oh-label">Country</div>
      <div class="oh-row">
        <div style="flex:1;"><select id="p-country-select">
          <option value="US" ${state.country === "US" ? "selected" : ""}>🇺🇸 USA · ${COUNTRY_PRESETS.US.length}</option>
          <option value="UK" ${state.country === "UK" ? "selected" : ""}>🇬🇧 UK · ${COUNTRY_PRESETS.UK.length}</option>
          <option value="AU" ${state.country === "AU" ? "selected" : ""}>🇦🇺 Australia · ${COUNTRY_PRESETS.AU.length}</option>
          <option value="CA" ${state.country === "CA" ? "selected" : ""}>🇨🇦 Canada · ${COUNTRY_PRESETS.CA.length}</option>
        </select></div>
        <div style="display:flex;gap:6px;align-items:center;flex:1;">
          <div style="flex:1;min-width:0;"><label class="oh-label">From city #</label><input class="oh-input" id="inp-range-start" type="number" value="${state.rangeStart}" min="1" max="${state.locations.length}" title="First city number"></div>
          <div style="flex:1;min-width:0;"><label class="oh-label">To city #</label><input class="oh-input" id="inp-range-end" type="number" value="${state.rangeEnd}" min="1" max="${state.locations.length}" title="Last city number"></div>
        </div>
      </div>
      <div style="margin-top:8px;"><label class="oh-label">Keyword to collect</label><textarea class="oh-input" id="p-keyword-input" rows="3" placeholder="e.g. Dental Clinic
Dentist
Orthodontist">${state.keyword}</textarea><div class="oh-muted" style="margin-top:4px;">Enter one complete keyword per line. Do not split phrases into individual words.</div></div>
      <div style="margin-top:8px;"><label class="oh-label">Category filter (optional)</label><input class="oh-input" id="p-category-filter" type="text" value="${String(state.categoryFilter || "").replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/</g, "&lt;").replace(/>/g, "&gt;")}" placeholder="e.g. Dentist, Dental Clinic"><div class="oh-muted" style="margin-top:4px;">Enter one or more categories separated by commas. Only matching Google Maps categories will be collected. Leave blank to collect all categories.</div></div>
    </div>

    <div class="oh-card">
      <div class="oh-label">Starting point</div>
      <div class="oh-row">
        <select id="p-location-select" style="flex:1;">
          ${state.locations.map((c, i) => `<option value="${i}" ${i === state.currentIdx ? "selected" : ""}>${i + 1}. ${c}</option>`).join("")}
        </select>
        <button id="p-skip-btn" class="oh-btn" style="background:#334155;">Go</button>
      </div>
    </div>

    <div class="oh-card">
      <div style="display:flex;gap:7px;">
        <div class="oh-stat"><b id="p-counter">${state.records.size}</b><span>Websites</span></div>
        <div class="oh-stat"><b id="p-city-progress">${Math.min(state.currentIdx, state.locations.length)}/${state.locations.length}</b><span>City progress</span></div><div class="oh-stat"><b id="p-failed-count">${Object.keys(state.failedJobs).length}</b><span>Failed jobs</span></div>
      </div>
      <div class="oh-progress"><i id="p-progress-bar"></i></div>
    </div>
    <div class="oh-card oh-log-card">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:7px;">
        <div>
          <div style="font-size:11px;font-weight:850;color:#f8fafc;">Live Activity Log</div>
          <div class="oh-muted" style="margin-top:2px;">Latest harvesting events</div>
        </div>
        <button id="p-clear-log" class="oh-btn" style="background:#1e293b;padding:5px 7px;font-size:9px;">Clear</button>
      </div>
      <div id="p-activity-log" class="oh-activity-log" aria-live="polite">
        <div class="oh-log-empty">No activity yet. Start harvesting to see live updates.</div>
      </div>
    </div>

    <div class="oh-card">
      <label class="oh-label">Google Sheets Web App URL</label>
      <input class="oh-input" id="p-webhook-input" placeholder="Paste Apps Script Web App URL" value="${state.webhookUrl}">
      <div class="oh-muted" style="margin-top:5px;">Sync is optional. CSV export remains available.</div>
    </div>

    <div style="display:grid;grid-template-columns:1.4fr 1fr 42px;gap:6px;margin-bottom:7px;">
      <button id="p-toggle" class="oh-btn" style="background:#16a34a;">▶ Start harvesting</button>
      <button id="p-download" class="oh-btn" style="background:#2563eb;">↓ Export CSV</button>
      <button id="p-sync-webhook" class="oh-btn" style="background:#7c3aed;" title="Sync websites to Google Sheets">⚡</button>
    </div>
    <button id="p-reset" style="width:100%;padding:5px;background:transparent;color:#64748b;border:1px solid #26364f;border-radius:7px;font-size:9px;cursor:pointer;">Reset progress & collected websites</button>
  `;

  document.body.appendChild(panel);

  const statusEl = document.getElementById("p-status");
  const countrySelect = document.getElementById("p-country-select");
  const locationSelect = document.getElementById("p-location-select");
  const skipBtn = document.getElementById("p-skip-btn");
  const counterEl = document.getElementById("p-counter");
  const cityProgressEl = document.getElementById("p-city-progress");
  const progressBarEl = document.getElementById("p-progress-bar");
  const nextBackupEl = document.getElementById("p-next-backup");
  const inpRangeStart = document.getElementById("inp-range-start");
  const inpRangeEnd = document.getElementById("inp-range-end");
  const webhookInput = document.getElementById("p-webhook-input");
  const syncWebhookBtn = document.getElementById("p-sync-webhook");
  const timerEl = document.getElementById("p-timer");
  const timerSec = document.getElementById("p-timer-sec");
  const toggleBtn = document.getElementById("p-toggle");
  const downloadBtn = document.getElementById("p-download");
  const resetBtn = document.getElementById("p-reset");
  const kwInput = document.getElementById("p-keyword-input");
  const categoryFilterInput = document.getElementById("p-category-filter");
  const activityLogEl = document.getElementById("p-activity-log");
  const clearLogBtn = document.getElementById("p-clear-log");
  const failedCountEl = document.getElementById("p-failed-count");

  const LOG_ICONS = { info: "i", success: "✓", warn: "!", error: "×" };
  function addActivity(message, type = "info") {
    if (!activityLogEl) return;
    const empty = activityLogEl.querySelector(".oh-log-empty");
    if (empty) empty.remove();
    const row = document.createElement("div");
    row.className = `oh-log-row oh-log-${type}`;
    const time = new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: false });
    row.innerHTML = `<span class="oh-log-time">${time}</span><span class="oh-log-icon">${LOG_ICONS[type] || "i"}</span><span class="oh-log-message"></span>`;
    row.querySelector(".oh-log-message").textContent = message;
    activityLogEl.prepend(row);
    while (activityLogEl.children.length > 80) activityLogEl.lastElementChild.remove();
  }

  clearLogBtn.addEventListener("click", () => {
    activityLogEl.innerHTML = `<div class="oh-log-empty">No activity yet. Start harvesting to see live updates.</div>`;
  });

  countrySelect.addEventListener("change", e => {
    state.country = e.target.value;
    state.locations = COUNTRY_PRESETS[state.country] || COUNTRY_PRESETS.US;
    state.currentIdx = 0;
    locationSelect.innerHTML = state.locations.map((c, i) => `<option value="${i}">[${i + 1}/${state.locations.length}] ${c}</option>`).join("");
    inpRangeStart.max = state.locations.length.toString();
    inpRangeEnd.max = state.locations.length.toString();
    state.rangeStart = 1;
    state.rangeEnd = Math.min(100, state.locations.length);
    inpRangeStart.value = state.rangeStart.toString();
    inpRangeEnd.value = state.rangeEnd.toString();
    cityProgressEl.innerText = `${state.currentIdx}/${state.locations.length}`;
    progressBarEl.style.width = `${Math.min(100, (state.currentIdx / Math.max(1, state.locations.length)) * 100)}%`;
    persistData();
    addActivity(`Switched to ${countrySelect.options[countrySelect.selectedIndex].textContent.trim()}`, "info");
  });

  function updateKeywordsFromInput() {
    state.keywords = kwInput.value.split(/\r?\n/).map(s => s.trim()).filter(Boolean);
    state.keyword = state.keywords.join("\n");
    persistData();
    addActivity(state.keywords.length ? `Loaded ${state.keywords.length} keyword${state.keywords.length === 1 ? "" : "s"}` : "Keywords cleared", "info");
  }
  kwInput.addEventListener("change", updateKeywordsFromInput);
  kwInput.addEventListener("blur", updateKeywordsFromInput);

  function updateCategoryFilter() {
    state.categoryFilter = categoryFilterInput.value.trim();
    persistData();
    addActivity(state.categoryFilter ? `Category filter set: ${state.categoryFilter}` : "Category filter cleared; all categories allowed", "info");
  }
  categoryFilterInput.addEventListener("change", updateCategoryFilter);
  categoryFilterInput.addEventListener("blur", updateCategoryFilter);

  webhookInput.addEventListener("change", e => {
    state.webhookUrl = e.target.value.trim();
    persistData();
  });

  function updateCityRange() {
    let start = parseInt(inpRangeStart.value, 10);
    let end = parseInt(inpRangeEnd.value, 10);
    const max = state.locations.length;
    if (isNaN(start)) start = 1;
    if (isNaN(end)) end = Math.min(100, max);
    start = Math.max(1, Math.min(start, max));
    end = Math.max(start, Math.min(end, max));
    state.rangeStart = start;
    state.rangeEnd = end;
    inpRangeStart.value = String(start);
    inpRangeEnd.value = String(end);
    state.maxCitiesToCollect = end - start + 1;
    persistData();
    addActivity(`City range set to ${start}–${end} (${end - start + 1} cities)`, "info");
  }
  inpRangeStart.addEventListener("change", updateCityRange);
  inpRangeEnd.addEventListener("change", updateCityRange);


  skipBtn.addEventListener("click", () => {
    state.currentIdx = parseInt(locationSelect.value, 10);
    cityProgressEl.innerText = `${state.currentIdx}/${state.locations.length}`;
    progressBarEl.style.width = `${Math.min(100, (state.currentIdx / Math.max(1, state.locations.length)) * 100)}%`;
    const city = state.locations[state.currentIdx];
    console.log(`Jumped to: [${state.currentIdx + 1}/${state.locations.length}] ${city}`);
    addActivity(`Starting point set to ${city}`, "info");
  });

  progressBarEl.style.width = `${Math.min(100, (state.currentIdx / Math.max(1, state.locations.length)) * 100)}%`;

  resetBtn.addEventListener("click", async () => {
    if (window.confirm("Clear all gathered records and progress?")) {
      try {
        localStorage.removeItem(STORAGE_KEY_IDX);
        localStorage.removeItem(STORAGE_KEY_KW);
        localStorage.removeItem(STORAGE_KEY_MAX_CITIES);
        localStorage.removeItem(STORAGE_KEY_RANGE_START);
        localStorage.removeItem(STORAGE_KEY_RANGE_END);
        localStorage.removeItem(STORAGE_KEY_CATEGORY_FILTER);
        localStorage.removeItem(STORAGE_KEY_PROGRESS);
      } catch {}
      try {
        const db = await openLeadDB();
        await new Promise((resolve, reject) => {
          const tx = db.transaction("leads", "readwrite");
          tx.objectStore("leads").clear();
          tx.oncomplete = resolve; tx.onerror = () => reject(tx.error);
        });
        db.close();
      } catch {}
      state.records.clear();
      state.websiteSet.clear();
      state.completedJobs.clear();
      state.failedJobs = {};
      state.currentIdx = 0;
      state.lastBackupMilestone = 0;
      counterEl.innerText = "0";
      if (failedCountEl) failedCountEl.innerText = "0";
      cityProgressEl.innerText = `0/${state.locations.length}`;
      progressBarEl.style.width = "0%";
      locationSelect.value = "0";
      if (nextBackupEl) nextBackupEl.innerText = state.autoBackupBatch.toString();
      locationSelect.value = "0";
      console.log("Memory cleared.");
      addActivity("Progress and collected websites cleared", "warn");
    }
  });

  async function pushToWebhook(recordsList, isSilent = false) {
    if (!state.webhookUrl) {
      if (!isSilent) alert("Please enter your Apps Script Web App URL first.");
      return;
    }
    syncWebhookBtn.innerText = "⏳";
    try {
      await fetch(state.webhookUrl, {
        method: "POST",
        mode: "no-cors",
        headers: { "Content-Type": "text/plain;charset=utf-8" },
        body: JSON.stringify({
          source: "GoogleMapsHarvester",
          country: state.country,
          keyword: state.keyword,
          timestamp: new Date().toISOString(),
          leads: recordsList
        })
      });
      console.log(`Dispatched ${recordsList.length} leads to Google Sheet.`);
      addActivity(`Saved ${recordsList.length.toLocaleString()} websites to Google Sheets`, "success");
      if (!isSilent) playBeep(880, 0.2);
      return true;
    } catch (err) {
      console.error("Webhook push failed:", err);
      addActivity("Google Sheets sync failed", "error");
      if (!isSilent) alert("Webhook sync failed. Verify script deployment URL.");
      return false;
    } finally {
      syncWebhookBtn.innerText = "⚡";
    }
  }

  syncWebhookBtn.addEventListener("click", () => pushToWebhook(Array.from(state.records.values()), false));

  function downloadCSV() {
    const list = Array.from(state.records.values());
    if (!list.length) {
      alert("No records collected to export.");
      return;
    }

    const headers = [
      "Country", "TargetCity", "Query", "CompanyName", "Category", 
      "PriceTier", "Status", "Website", "Street", "City", "StateCode", "ZipCode", 
      "Latitude", "Longitude", "GoogleMapsUrl"
    ];
    const esc = val => `"${String(val ?? "").replace(/"/g, '""').replace(/\r?\n/g, " ")}"`;

    const csvRows = [
      headers.join(","),
      ...list.map(r => headers.map(h => esc(r[h])).join(","))
    ];

    const blob = new Blob(["\ufeff" + csvRows.join("\n")], { type: "text/csv;charset=utf-8;" });
    const dlUrl = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = dlUrl;
    a.download = `${state.country}_${state.keyword.replace(/\s+/g, "_")}_${list.length}leads.csv`.toLowerCase();
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(dlUrl), 2000);
    addActivity(`Exported ${list.length.toLocaleString()} websites to CSV`, "success");
  }

  async function checkSyncThreshold() {
    const count = state.records.size;
    const nextMilestone = state.lastBackupMilestone + state.autoBackupBatch;

    if (count < nextMilestone) return;
    if (!state.webhookUrl) return;
    if (state.syncInProgress) return;

    state.syncInProgress = true;

    // Send only the records collected since the previous sync.
    // This prevents sending all old records again at every 500-lead milestone.
    const records = Array.from(state.records.entries());
    const batch = records
      .slice(state.lastBackupMilestone, nextMilestone)
      .map(([, record]) => record);

    if (batch.length < state.autoBackupBatch) return;

    const syncSucceeded = await pushToWebhook(batch, true);

    if (syncSucceeded) {
      state.lastBackupMilestone = nextMilestone;
      if (nextBackupEl) {
        nextBackupEl.innerText = (nextMilestone + state.autoBackupBatch).toString();
      }
      await persistData();
    }

    state.syncInProgress = false;
  }

  function parseCards(feed, currentCity, currentKeyword) {
    if (!feed) return;
    const cards = feed.querySelectorAll(".Nv2PK");

    cards.forEach(card => {
      try {
        const anchor = card.querySelector('a.hfpxzc, a[href*="/maps/place/"]');
        const placeUrl = anchor ? anchor.href : "";
        if (!placeUrl) return;

        let latitude = "", longitude = "";
        const coordMatch = placeUrl.match(/!3d(-?\d+\.\d+)!4d(-?\d+\.\d+)/);
        if (coordMatch) {
          latitude = coordMatch[1];
          longitude = coordMatch[2];
        }

        const placeToken = (placeUrl.match(/1s(0x[0-9a-f:]+)/) || [])[1] || placeUrl;
        if (state.records.has(placeToken)) return;

        const nameEl = card.querySelector(".qBF1Pd, .fontHeadlineSmall, [role='heading']");
        const companyName = nameEl ? nameEl.textContent.trim() : "";
        if (!companyName) return;

        const siteAnchor = card.querySelector('a[data-value="Website"], a[aria-label*="website" i], a.lcr4fd');
        let website = siteAnchor ? cleanDomain(siteAnchor.href) : "";

        if (state.filterAggregators && website) {
          const isAggregator = AGGREGATOR_DOMAINS.some(d => website.toLowerCase().includes(d));
          if (isAggregator) website = "";
        }

        if (!website) return;
        if (state.websiteSet.has(website)) return;

        const textContainers = card.querySelectorAll(".W4Efsd");
        let rawAddress = "";
        let category = "";
        let priceTier = "";
        let openStatus = "";

        textContainers.forEach(container => {
          const text = container.textContent.trim();

          const priceMatch = text.match(/[$€£¥]{1,4}/);
          if (priceMatch && !priceTier) priceTier = priceMatch[0];

          if (/open|closed|opens soon|closing soon/i.test(text) && !openStatus) {
            const statusMatch = text.match(/(Open 24 hours|Open ⋅ Closes [^·]+|Closed ⋅ Opens [^·]+|Closed)/i);
            if (statusMatch) openStatus = statusMatch[0];
          }

          const segments = text.split("·").map(s => s.trim());
          if (segments.length > 1) {
            if (!category && isNaN(segments[0])) category = segments[0];
            const addressCandidate = segments.find(s => /\d+/.test(s) && !s.includes("$"));
            if (addressCandidate && !rawAddress) rawAddress = addressCandidate;
          }
        });

        const requestedCategories = String(state.categoryFilter || "")
          .split(/[,\n]/)
          .map(value => value.trim().toLowerCase())
          .filter(Boolean);
        if (requestedCategories.length) {
          const actualCategory = String(category || "").toLowerCase();
          const matchesCategory = requestedCategories.some(requested =>
            actualCategory.includes(requested) || requested.includes(actualCategory)
          );
          if (!actualCategory || !matchesCategory) return;
        }

        const addressData = parseAddress(rawAddress);

        const record = {
          Country: state.country,
          TargetCity: currentCity,
          Query: `${currentKeyword} in ${currentCity}`,
          keyword: currentKeyword,
          CompanyName: companyName,
          Category: category,
          PriceTier: priceTier,
          Status: openStatus,
          Website: website,
          Street: addressData.Street,
          City: addressData.City || currentCity,
          StateCode: addressData.StateCode,
          ZipCode: addressData.Zip,
          Latitude: latitude,
          Longitude: longitude,
          GoogleMapsUrl: placeUrl
        };

        state.records.set(placeToken, record);
        state.websiteSet.add(website);
        counterEl.innerText = state.records.size.toString();
        checkSyncThreshold();
      } catch (err) {
        console.debug("Card extraction skipped:", err);
      }
    });

    persistData();
  }

  async function scrollFeedUntilEnd(feed, currentCity, currentKeyword) {
    let lastHeight = 0;
    let staleCount = 0;

    while (state.isRunning) {
      if (checkCaptcha()) {
        state.isRunning = false;
        updateRunStateUI();
        break;
      }

      parseCards(feed, currentCity, currentKeyword);

      feed.scrollTop = feed.scrollHeight;
      await randomSleep(1200, 1800);

      const endNotice = document.body.innerText.includes("You've reached the end of the list");
      if (endNotice) break;

      if (feed.scrollHeight === lastHeight) {
        staleCount++;
        if (staleCount >= 4) break;
      } else {
        staleCount = 0;
        lastHeight = feed.scrollHeight;
      }
    }
  }

  function updateRunStateUI() {
    if (state.isRunning) {
      statusEl.innerText = "RUNNING";
      statusEl.style.background = "#22c55e";
      toggleBtn.innerText = "⏸ Pause";
      toggleBtn.style.background = "#eab308";
    } else {
      statusEl.innerText = "PAUSED";
      statusEl.style.background = "#ef4444";
      toggleBtn.innerText = "▶ Start";
      toggleBtn.style.background = "#22c55e";
      if (timerEl) timerEl.style.display = "none";
    }
  }

  async function runOrchestrator() {
    let citiesProcessedThisRun = 0;
    const rangeStartIdx = Math.max(0, state.rangeStart - 1);
    const rangeEndExclusive = Math.min(state.rangeEnd, state.locations.length);
    if (state.currentIdx < rangeStartIdx || state.currentIdx >= rangeEndExclusive) {
      state.currentIdx = rangeStartIdx;
      locationSelect.value = state.currentIdx.toString();
    }
    const keywords = getKeywords();
    if (!keywords.length) {
      addActivity("Enter at least one keyword before starting", "warn");
      return;
    }

    while (state.isRunning && state.currentIdx < rangeEndExclusive) {
      const currentCity = state.locations[state.currentIdx];
      locationSelect.value = state.currentIdx.toString();
      let cityHadWork = false;

      for (const currentKeyword of keywords) {
        if (!state.isRunning) break;
        const key = jobKey(currentCity, currentKeyword);
        if (state.completedJobs.has(key)) continue;

        const priorFailures = state.failedJobs[key] || 0;
        if (priorFailures >= MAX_CITY_RETRIES) {
          addActivity(`Skipped after ${MAX_CITY_RETRIES} failed attempts — ${currentCity} / ${currentKeyword}`, "error");
          continue;
        }

        cityHadWork = true;
        const query = `${currentKeyword} in ${currentCity}`;
        addActivity(`Searching ${currentCity} — “${currentKeyword}”`, "info");
        await triggerSearch(query);

        if (timerEl) timerEl.style.display = "block";
        for (let sec = SETTLE_DELAY_SEC; sec > 0; sec--) {
          if (!state.isRunning) break;
          if (timerSec) timerSec.innerText = sec.toString();
          await sleep(1000);
        }
        if (timerEl) timerEl.style.display = "none";
        if (!state.isRunning) break;

        let feed = null;
        for (let attempt = 0; attempt < 5; attempt++) {
          feed = findFeed();
          if (feed) break;
          await sleep(1000);
        }

        if (feed) {
          const beforeCount = state.records.size;
          await scrollFeedUntilEnd(feed, currentCity, currentKeyword);
          const addedCount = state.records.size - beforeCount;
          markJobComplete(currentCity, currentKeyword);
          addActivity(addedCount > 0 ? `Collected ${addedCount.toLocaleString()} websites — ${currentCity}` : `No new websites found — ${currentCity}`, addedCount > 0 ? "success" : "warn");
          await persistData();
        } else {
          const attempts = markJobFailed(currentCity, currentKeyword);
          addActivity(`Could not load results — ${currentCity} (${currentKeyword}) — retry ${attempts}/${MAX_CITY_RETRIES}`, "error");
          await persistData();
          if (attempts < MAX_CITY_RETRIES) {
            await randomSleep(2500, 4500);
            continue;
          }
        }
      }

      if (!state.isRunning) break;
      state.currentIdx++;
      citiesProcessedThisRun++;
      cityProgressEl.innerText = `${state.currentIdx}/${state.locations.length}`;
      progressBarEl.style.width = `${Math.min(100, (state.currentIdx / Math.max(1, state.locations.length)) * 100)}%`;
      if (failedCountEl) failedCountEl.innerText = Object.keys(state.failedJobs).length.toString();
      await persistData();
      if (cityHadWork) await randomSleep(2000, 3500);
    }

    if (state.currentIdx >= rangeEndExclusive) {
      state.isRunning = false;
      updateRunStateUI();
      playBeep(1000, 0.5);
      addActivity(`Finished city range ${state.rangeStart}–${state.rangeEnd}. Set the next range to continue.`, "success");
    }
  }

  toggleBtn.addEventListener("click", () => {
    if (!state.isRunning) {
      updateKeywordsFromInput();
      if (!state.keywords.length) {
        addActivity("Enter a keyword before starting", "warn");
        alert("Please enter the keyword you want to collect.");
        kwInput.focus();
        return;
      }
      persistData();
      updateCityRange();
      const startIdx = state.rangeStart - 1;
      const endExclusive = Math.min(state.rangeEnd, state.locations.length);
      if (state.currentIdx < startIdx || state.currentIdx >= endExclusive) {
        state.currentIdx = startIdx;
      }

      state.isRunning = true;
      updateRunStateUI();
      addActivity(`Started collection — cities ${state.rangeStart}–${state.rangeEnd}; ${state.keywords.length} keyword${state.keywords.length === 1 ? "" : "s"}`, "success");
      runOrchestrator();
    } else {
      state.isRunning = false;
      updateRunStateUI();
      addActivity("Collection paused", "warn");
    }
  });

  downloadBtn.addEventListener("click", downloadCSV);
})();