(() => {
  if (window.__emailScannerStop) window.__emailScannerStop();
  document.getElementById("email-scan-mini")?.remove();
  document.getElementById("email-scan-style")?.remove();

  const MAX_PAGES=10, LOAD_TIMEOUT_MS=90000, STABLE_CHECKS_REQUIRED=3, CHECK_INTERVAL_MS=1500;
  let stopped=false, scanning=false;
  window.__emailScannerStop=()=>{stopped=true;};
  const collected=new Set(), sleep=ms=>new Promise(r=>setTimeout(r,ms));
  const panel=document.createElement("section"); panel.id="email-scan-mini";
  panel.innerHTML=`<header id="email-scan-head"><span class="es-brand"><span class="es-dot"></span>Email Scanner</span><button id="es-close" class="es-close">×</button></header>
  <div class="es-status"><span class="es-pulse"></span><span id="es-status-text">Ready</span></div>
  <div class="es-count" id="es-count">Unique emails: 0</div>
  <div class="es-track"><div id="es-bar"></div></div>
  <div class="es-actions"><button id="es-start" class="es-start">Start scan</button><button id="es-stop" class="es-stop">Stop & download CSV</button></div>
  <p class="es-note">Collects email addresses visible in page text, removes duplicates, and scans up to 10 pages. Use only where you’re authorized to collect and process these addresses.</p>`;
  const style=document.createElement("style"); style.id="email-scan-style";
  style.textContent=`#email-scan-mini{position:fixed;right:20px;top:100px;z-index:2147483647;width:285px;box-sizing:border-box;padding:14px;background:#fff;color:#172033;border:1px solid #dbe3f2;border-radius:16px;box-shadow:0 12px 38px #18284a30;font:13px/1.45 Arial,sans-serif}#email-scan-mini *{box-sizing:border-box}#email-scan-head{display:flex;justify-content:space-between;align-items:center;margin-bottom:14px;cursor:move;font-size:15px;font-weight:800}.es-brand{display:flex;align-items:center;gap:8px}.es-dot{width:10px;height:10px;border-radius:50%;background:linear-gradient(135deg,#059669,#0d9488);box-shadow:0 0 0 4px #d1fae5}.es-close{border:0;border-radius:8px;background:#f1f5f9;color:#475569;width:27px;height:27px;font-size:19px;cursor:pointer}.es-status{display:flex;gap:8px;align-items:center;padding:9px 10px;border-radius:9px;background:#f8fafc;min-height:36px}.es-pulse{width:8px;height:8px;border-radius:50%;background:#059669;flex:none}.es-count{margin:12px 0 7px;color:#475569}.es-track{height:7px;border-radius:20px;background:#e8edf5;overflow:hidden}#es-bar{height:100%;width:0;background:linear-gradient(90deg,#059669,#0d9488);transition:width .2s}.es-actions{display:grid;gap:8px;margin-top:13px}#email-scan-mini .es-actions button{border:0;border-radius:9px;padding:10px;color:white;font-weight:700;cursor:pointer}#email-scan-mini .es-start{background:linear-gradient(135deg,#059669,#0d9488)}#email-scan-mini .es-stop{background:linear-gradient(135deg,#e11d48,#f97316)}#email-scan-mini button:hover{filter:brightness(1.07)}.es-note{font-size:11px;color:#64748b;line-height:1.5;margin:12px 0 0;padding-top:10px;border-top:1px solid #edf0f6}`;
  document.documentElement.appendChild(style); document.body.appendChild(panel);
  const status=(msg,color="#059669")=>{const t=panel.querySelector("#es-status-text"),d=panel.querySelector(".es-pulse");if(t)t.textContent=msg;if(d)d.style.background=color;};
  const update=(msg,page)=>{if(!panel.isConnected)return;status(`${msg} — page ${page}/${MAX_PAGES}`);panel.querySelector("#es-count").textContent=`Unique emails: ${collected.size}`;panel.querySelector("#es-bar").style.width=`${Math.min(100,page/MAX_PAGES*100)}%`;};
  const range=()=>{const m=(document.body.innerText||"").match(/([\d,]+)\s*-\s*([\d,]+)\s+of\s+([\d,]+)\s+matches/i);return m?{first:+m[1].replace(/,/g,""),last:+m[2].replace(/,/g,""),total:+m[3].replace(/,/g,"")}:null;};
  const scan=()=>{const found=(document.body.innerText||"").match(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi)||[];found.forEach(x=>collected.add(x.toLowerCase()));return found.length;};
  const nextButton=()=>[...document.querySelectorAll("button")].find(b=>/next page/i.test(`${b.innerText||""} ${b.getAttribute("aria-label")||""} ${b.title||""}`)&&b.getClientRects().length);
  const signature=()=>{const r=range();return `${r?.first??"?"}:${[...document.querySelectorAll("tbody tr")].map(x=>x.innerText).join("|").slice(0,2500)}`;};
  async function waitChange(previousFirst){const deadline=Date.now()+LOAD_TIMEOUT_MS;let last="",stable=0;while(Date.now()<deadline&&!stopped){await sleep(CHECK_INTERVAL_MS);const r=range(),loading=/searching\.\.\.|loading\.\.\./i.test(document.body.innerText||""),sig=signature();if(r&&r.first!==previousFirst&&!loading&&sig===last)stable++;else stable=0;last=sig;if(stable>=STABLE_CHECKS_REQUIRED)return true;}return false;}
  function download(){if(!collected.size){status("No visible emails found.", "#e11d48");return;}const esc=x=>`"${String(x).replace(/"/g,'""')}"`;const csv=["Email",...[...collected].map(esc)].join("\r\n");const url=URL.createObjectURL(new Blob(["\uFEFF",csv],{type:"text/csv;charset=utf-8;"}));const a=document.createElement("a");a.href=url;a.download=`consulti_emails_${new Date().toISOString().slice(0,10)}.csv`;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),3000);status(`CSV download requested (${collected.size} unique).`);}
  async function run(){if(scanning)return;scanning=true;stopped=false;panel.querySelector("#es-start").disabled=true;try{for(let i=0;i<MAX_PAGES&&!stopped;i++){update("Waiting for records",i+1);await sleep(2500);if(stopped)break;const r=range();if(!r){status("Results range not found; stopped.", "#d97706");break;}const n=scan();console.log(`[Email Scanner] page ${i+1}, ${r.first}-${r.last}: ${n} matches, ${collected.size} unique`);update("Collected visible emails",i+1);if(i===MAX_PAGES-1||r.last>=r.total)break;const next=nextButton();if(!next||next.disabled){status("Next-page control unavailable.", "#e11d48");break;}next.click();update("Waiting for next page",i+1);if(!(await waitChange(r.first))&&!stopped){status("Page change timed out.", "#e11d48");break;}}}catch(e){console.error(e);status("Scanner stopped due to an error.", "#e11d48");}finally{scanning=false;panel.querySelector("#es-start").disabled=false;download();}}
  panel.querySelector("#es-start").addEventListener("click",run);
  panel.querySelector("#es-stop").addEventListener("click",()=>{stopped=true;if(!scanning)download();});
  panel.querySelector("#es-close").addEventListener("click",()=>{stopped=true;panel.remove();style.remove();});
  const head=panel.querySelector("#email-scan-head");let drag=false,dx=0,dy=0;
  head.addEventListener("mousedown",e=>{if(e.target.closest("button"))return;drag=true;dx=e.clientX-panel.offsetLeft;dy=e.clientY-panel.offsetTop;e.preventDefault();});
  document.addEventListener("mousemove",e=>{if(!drag||!panel.isConnected)return;panel.style.left=`${e.clientX-dx}px`;panel.style.top=`${e.clientY-dy}px`;panel.style.right="auto";});
  document.addEventListener("mouseup",()=>drag=false);
  status("Ready. Click Start scan.");
})();