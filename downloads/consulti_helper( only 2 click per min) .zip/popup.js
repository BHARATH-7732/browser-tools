async function launch(file){
 const msg=document.getElementById("msg");
 try{
  const [tab]=await chrome.tabs.query({active:true,currentWindow:true});
  if(!tab?.id||!/^https?:/.test(tab.url||"")){msg.textContent="Open the Consulti results page in a normal browser tab first.";return;}
  await chrome.scripting.executeScript({target:{tabId:tab.id},files:[file]});
  msg.textContent="Launched. Check the page.";
  window.close();
 }catch(e){msg.textContent="Could not launch. Refresh the page and try again.";}
}
document.getElementById("lead").addEventListener("click",()=>launch("content.js"));
document.getElementById("email").addEventListener("click",()=>launch("email-scanner.js"));