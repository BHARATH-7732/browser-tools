(() => {
  if (window.__emailScannerStop) window.__emailScannerStop();
  document.getElementById("email-scan-mini")?.remove();
  document.getElementById("email-scan-style")?.remove();

  const MAX_PAGES=50, LOAD_TIMEOUT_MS=90000, STABLE_CHECKS_REQUIRED=3, CHECK_INTERVAL_MS=1500;
  let stopped=false, scanning=false;
  window.__emailScannerStop=()=>{stopped=true;};
  const sleep=ms=>new Promise(r=>setTimeout(r,ms));
  const records=new Map();
  const panel=document.createElement("section"); panel.id="email-scan-mini";
  panel.innerHTML=`<header id="email-scan-head"><span class="es-brand"><span class="es-dot"></span>Lead Scanner</span><button id="es-close" class="es-close">×</button></header>
  <div class="es-status"><span class="es-pulse"></span><span id="es-status-text">Ready</span></div>
  <div class="es-count" id="es-count">Unique leads: 0</div><div class="es-track"><div id="es-bar"></div></div>
  <div class="es-actions"><button id="es-start" class="es-start">Start scan</button><button id="es-stop" class="es-stop">Stop & download CSV</button></div>
  <p class="es-note">Collects visible lead-table fields across up to 50 pages: name, first name, last name, title, company, email, status, industry, location, employee count, LinkedIn URL, plus any additional visible columns. Missing fields are left blank.</p>`;
  const style=document.createElement("style"); style.id="email-scan-style";
  style.textContent=`#email-scan-mini{position:fixed;right:20px;top:100px;z-index:2147483647;width:300px;box-sizing:border-box;padding:14px;background:#fff;color:#172033;border:1px solid #dbe3f2;border-radius:16px;box-shadow:0 12px 38px #18284a30;font:13px/1.45 Arial,sans-serif}#email-scan-mini *{box-sizing:border-box}#email-scan-head{display:flex;justify-content:space-between;align-items:center;margin-bottom:14px;cursor:move;font-size:15px;font-weight:800}.es-brand{display:flex;align-items:center;gap:8px}.es-dot{width:10px;height:10px;border-radius:50%;background:linear-gradient(135deg,#059669,#0d9488);box-shadow:0 0 0 4px #d1fae5}.es-close{border:0;border-radius:8px;background:#f1f5f9;color:#475569;width:27px;height:27px;font-size:19px;cursor:pointer}.es-status{display:flex;gap:8px;align-items:center;padding:9px 10px;border-radius:9px;background:#f8fafc;min-height:36px}.es-pulse{width:8px;height:8px;border-radius:50%;background:#059669;flex:none}.es-count{margin:12px 0 7px;color:#475569}.es-track{height:7px;border-radius:20px;background:#e8edf5;overflow:hidden}#es-bar{height:100%;width:0;background:linear-gradient(90deg,#059669,#0d9488);transition:width .2s}.es-actions{display:grid;gap:8px;margin-top:13px}#email-scan-mini .es-actions button{border:0;border-radius:9px;padding:10px;color:white;font-weight:700;cursor:pointer}#email-scan-mini .es-start{background:linear-gradient(135deg,#059669,#0d9488)}#email-scan-mini .es-stop{background:linear-gradient(135deg,#e11d48,#f97316)}#email-scan-mini button:hover{filter:brightness(1.07)}.es-note{font-size:11px;color:#64748b;line-height:1.5;margin:12px 0 0;padding-top:10px;border-top:1px solid #edf0f6}`;
  document.documentElement.appendChild(style); document.body.appendChild(panel);
  const status=(msg,color="#059669")=>{const t=panel.querySelector("#es-status-text"),d=panel.querySelector(".es-pulse");if(t)t.textContent=msg;if(d)d.style.background=color;};
  const update=(msg,page)=>{if(!panel.isConnected)return;status(`${msg} — page ${page}/${MAX_PAGES}`);panel.querySelector("#es-count").textContent=`Unique leads: ${records.size}`;panel.querySelector("#es-bar").style.width=`${Math.min(100,page/MAX_PAGES*100)}%`;};
  // Normalize cell text and remove UI-only copy controls from scraped values.
  const norm=s=>(s||"").replace(/\bcopy\s+e-?mail\b/gi, "").replace(/\s+/g," ").trim();
  const emailFrom=s=>{const m=(s||"").match(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i);return m?m[0]:"";};
  const range=()=>{const m=(document.body.innerText||"").match(/([\d,]+)\s*-\s*([\d,]+)\s+of\s+([\d,]+)\s+matches/i);return m?{first:+m[1].replace(/,/g,""),last:+m[2].replace(/,/g,""),total:+m[3].replace(/,/g,"")}:null;};
  const table=()=>document.querySelector("table");
  const headers=()=>{const t=table(); if(!t)return [];return [...t.querySelectorAll("thead th")].map((th,i)=>norm(th.innerText)||`Column ${i+1}`);};
  const canonical=h=>{
    const x=norm(h).toLowerCase();
    if(/^(first name|firstname|given name|forename)$/.test(x))return "First Name";
    if(/^(last name|lastname|surname|family name)$/.test(x))return "Last Name";
    if(/^(name|person|full name|contact name|lead name)$/.test(x))return "Name";
    if(/title|job title|position|designation/.test(x))return "Title";
    if(/company website|website|web site|company url|homepage|company site/.test(x))return "Company Website";
    if(/company domain|domain/.test(x))return "Company Domain";
    if(/company|organization|organisation|account/.test(x))return "Company";
    if(/e.?mail/.test(x))return "Email";
    if(/status|verification|deliverability/.test(x))return "Email Status";
    if(/industry|sector/.test(x))return "Industry";
    if(/location|country|city|region|state/.test(x))return "Location";
    if(/employee|company size|headcount|employees/.test(x))return "Employees (approx.)";
    if(/linkedin/.test(x))return "LinkedIn URL";
    return norm(h)||"Other";
  };
  function extractRows(){
    const t=table();if(!t)return 0;
    const hs=headers(), trs=[...t.querySelectorAll("tbody tr")].filter(tr=>tr.getClientRects().length);
    let added=0;
    for(const tr of trs){
      const cells=[...tr.querySelectorAll("td")];if(!cells.length)continue;
      const obj={"Name":"","First Name":"","Last Name":"","Title":"","Company":"","Email":"","Email Status":"","Industry":"","Location":"","Employees (approx.)":"","LinkedIn URL":"","Company Website":"","Company Domain":"","Lead Source":"Consulti.ai","Scanned At":new Date().toISOString()};
      cells.forEach((td,i)=>{
        const rawHeader=norm(hs[i]||`Column ${i+1}`);
        const h=canonical(rawHeader), rawValue=norm(td.innerText);
        // Email cells often include a website button label such as “Copy email”.
        // Export only the actual address for the Email field.
        const value=h==="Email" ? emailFrom(td.innerText) : rawValue;
        if(value){
          if(h==="Name"||h==="First Name"||h==="Last Name"||h==="Title"||h==="Company"||h==="Email"||h==="Email Status"||h==="Industry"||h==="Location"||h==="Employees (approx.)"||h==="LinkedIn URL"||h==="Company Website"||h==="Company Domain"){
            if(!obj[h])obj[h]=value;
          } else {
            // Keep every additional visible table column under its original header.
            obj[rawHeader]=value;
          }
        }
        const links=[...td.querySelectorAll("a[href]")].map(a=>a.href).filter(u=>/^https?:/i.test(u));
        const linkedin=links.find(u=>/linkedin\.com\//i.test(u));
        if(linkedin)obj["LinkedIn URL"]=linkedin;
        // Capture a company website from a company-cell link when present; never treat LinkedIn as the company site.
        const companyLink=links.find(u=>!/linkedin\.com\//i.test(u)&&!/mailto:/i.test(u));
        if(companyLink && (h==="Company"||/website|site|url|homepage/i.test(rawHeader)) && !obj["Company Website"]) obj["Company Website"]=companyLink;
        if(h==="Company Website" && /^https?:/i.test(rawValue)) obj["Company Website"]=rawValue;
        if(h==="Company Domain" && rawValue) obj["Company Domain"]=rawValue.replace(/^https?:\/\//i,"").split("/")[0].replace(/^www\./i,"");
        if(h==="Email"&&!obj.Email){
          const m=emailFrom(td.innerText);
          if(m)obj.Email=m;
        }
      });
      if(!obj.Email){const m=emailFrom(tr.innerText);if(m)obj.Email=m;}
      if(obj["Company Website"]){
        try { const u=new URL(obj["Company Website"],location.href); if(/^https?:$/.test(u.protocol)){obj["Company Website"]=u.href; if(!obj["Company Domain"])obj["Company Domain"]=u.hostname.replace(/^www\./i,"");} } catch(e) {}
      }
      // Prefer explicit first/last-name columns; otherwise split the visible full-name value.
      if(obj.Name){
        const full=obj.Name.replace(/\s+/g," ").trim();
        if(!obj["First Name"] || !obj["Last Name"]){
          const parts=full.split(" ");
          if(!obj["First Name"])obj["First Name"]=parts.shift()||"";
          if(!obj["Last Name"])obj["Last Name"]=parts.join(" ");
        }
      }
      if(!obj.Name && (obj["First Name"]||obj["Last Name"]))obj.Name=[obj["First Name"],obj["Last Name"]].filter(Boolean).join(" ");
      const key=(obj.Email||"").toLowerCase()||`${obj.Name}|${obj.Company}|${obj.Title}`.toLowerCase();
      if(key.replace(/\|/g,"").trim()){
        if(records.has(key)){
          const old=records.get(key);
          Object.entries(obj).forEach(([k,v])=>{if(v&&(!old[k]||old[k]===""))old[k]=v;});
        } else {records.set(key,obj);added++;}
      }
    }
    return added;
  }

  const nextButton=()=>[...document.querySelectorAll("button")].find(b=>/next page/i.test(`${b.innerText||""} ${b.getAttribute("aria-label")||""} ${b.title||""}`)&&b.getClientRects().length);
  const signature=()=>{const r=range();return `${r?.first??"?"}:${[...document.querySelectorAll("tbody tr")].map(x=>x.innerText).join("|").slice(0,2500)}`;};
  async function waitChange(previousFirst){const deadline=Date.now()+LOAD_TIMEOUT_MS;let last="",stable=0;while(Date.now()<deadline&&!stopped){await sleep(CHECK_INTERVAL_MS);const r=range(),loading=/searching\.\.\.|loading\.\.\./i.test(document.body.innerText||""),sig=signature();if(r&&r.first!==previousFirst&&!loading&&sig===last)stable++;else stable=0;last=sig;if(stable>=STABLE_CHECKS_REQUIRED)return true;}return false;}
  function download(){
    if(!records.size){status("No lead rows found.", "#e11d48");return;}
    const all=[...records.values()], preferred=["Name","First Name","Last Name","Title","Company","Email","Email Status","Industry","Location","Employees (approx.)","LinkedIn URL","Company Website","Company Domain","Lead Source","Scanned At"];
    const cols=[...preferred,...new Set(all.flatMap(o=>Object.keys(o)).filter(k=>!preferred.includes(k)))];
    const esc=x=>`"${String(x??"").replace(/"/g,'""')}"`;
    const csv=[cols.map(esc).join(","),...all.map(o=>cols.map(k=>esc(o[k]||"")).join(","))].join("\r\n");
    const url=URL.createObjectURL(new Blob(["\uFEFF",csv],{type:"text/csv;charset=utf-8"}));const a=document.createElement("a");a.href=url;a.download=`consulti_leads_${new Date().toISOString().slice(0,10)}.csv`;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),3000);status(`CSV downloaded/requested: ${records.size} leads.`);
  }
  async function run(){if(scanning)return;scanning=true;stopped=false;panel.querySelector("#es-start").disabled=true;try{
    for(let i=0;i<MAX_PAGES&&!stopped;i++){
      update("Reading lead rows",i+1);await sleep(1800);if(stopped)break;
      const before=records.size, n=extractRows();console.log(`[Lead Scanner] page ${i+1}: ${n} new rows, ${records.size} total`);
      update(`Captured ${records.size-before} new leads`,i+1);
      const r=range();if(i===MAX_PAGES-1||(r&&r.last>=r.total))break;
      const next=nextButton();if(!next||next.disabled){status("Next-page control unavailable; exported collected rows.", "#d97706");break;}
      const oldFirst=r?.first??null;next.click();update("Waiting for next page",i+1);
      if(!(await waitChange(oldFirst))&&!stopped){status("Page change timed out; exporting collected rows.", "#d97706");break;}
    }
  }catch(e){console.error(e);status("Scanner stopped due to an error; exporting collected rows.", "#e11d48");}
  finally{scanning=false;panel.querySelector("#es-start").disabled=false;download();}}
  panel.querySelector("#es-start").addEventListener("click",run);
  panel.querySelector("#es-stop").addEventListener("click",()=>{stopped=true;if(!scanning)download();});
  panel.querySelector("#es-close").addEventListener("click",()=>{stopped=true;panel.remove();style.remove();});
  const head=panel.querySelector("#email-scan-head");let drag=false,dx=0,dy=0;
  head.addEventListener("mousedown",e=>{if(e.target.closest("button"))return;drag=true;dx=e.clientX-panel.offsetLeft;dy=e.clientY-panel.offsetTop;e.preventDefault();});
  document.addEventListener("mousemove",e=>{if(!drag||!panel.isConnected)return;panel.style.left=`${e.clientX-dx}px`;panel.style.top=`${e.clientY-dy}px`;panel.style.right="auto";});
  document.addEventListener("mouseup",()=>drag=false);
  status("Ready. Click Start scan.");
})();